#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250-xorg/lib:/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export GALLIUM_DRIVER=radeonsi MESA_LOADER_DRIVER_OVERRIDE=radeonsi
export keep_native_window_glx_drawable=true
set +e
timeout 45 /opt/piglit/lib/piglit/bin/glx-oml-sync-control-swapbuffersmsc-return 1 -auto -fbo > /work/parity002/oml-return-one-native.out 2> /work/parity002/oml-return-one-native.err
rc=$?; echo "$rc" > /work/parity002/oml-return-one-native.exit
