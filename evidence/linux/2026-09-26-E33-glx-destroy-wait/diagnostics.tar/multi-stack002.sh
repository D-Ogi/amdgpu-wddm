#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json
export GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true
unset RADV_DEBUG MESA_GL_VERSION_OVERRIDE MESA_GLSL_VERSION_OVERRIDE
set +e
timeout 30 /work/build/piglit/bin/gl-1.0-swapbuffers-behavior -auto > /work/parity002/multi-stack002-control.out 2> /work/parity002/multi-stack002-control.err
rc=$?; echo "$rc" > /work/parity002/multi-stack002-control.exit
[ "$rc" = 0 ] || exit "$rc"
for test in glx-make-current-other-thread glx-make-glxdrawable-current glx-multi-context-front glx-multi-context-ib-1 glx-multi-context-single-window; do
 extra=''; [ "$test" != glx-make-current-other-thread ] || extra='-fbo'
 timeout 45 /opt/piglit/lib/piglit/bin/$test -auto $extra > /work/parity002/multi-stack002-$test.out 2> /work/parity002/multi-stack002-$test.err
 rc=$?; echo "$rc" > /work/parity002/multi-stack002-$test.exit
 [ "$rc" = 0 ] || exit "$rc"
done
/opt/piglit/lib/piglit/bin/glx-multi-window-single-context -auto > /work/parity002/multi-stack002.out 2> /work/parity002/multi-stack002.err &
p=$!
echo "$p" > /work/parity002/multi-stack002-test.pid
(sleep 45; kill -TERM "$p" 2>/dev/null) &
watchdog=$!
sleep 10
if kill -0 "$p" 2>/dev/null; then
 timeout 15 gdb -nx -batch -ex 'set pagination off' -ex 'thread apply all bt 12' -p "$p" > /work/parity002/multi-stack002.bt 2>&1
fi
wait "$p"; rc=$?
echo "$rc" > /work/parity002/multi-stack002.exit
kill "$watchdog" 2>/dev/null
