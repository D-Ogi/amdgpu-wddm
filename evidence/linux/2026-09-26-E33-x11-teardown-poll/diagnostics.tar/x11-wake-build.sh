#!/bin/sh
set -eu
cd /work/src/mesa-05e6c9622e135ac2aeaf56ec70222642627e2162
cmp src/vulkan/wsi/wsi_common_x11.c /work/parity002/wsi_common_x11.original.c
patch -p1 < /work/parity002/x11-wake.patch
ninja -C /work/build/mesa src/amd/vulkan/libvulkan_radeon.so
mkdir /opt/bc250-x11-wake
cp /work/build/mesa/src/amd/vulkan/libvulkan_radeon.so /opt/bc250-x11-wake/
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json')
d=json.loads(p.read_text());d['ICD']['library_path']='/opt/bc250-x11-wake/libvulkan_radeon.so'
Path('/opt/bc250-x11-wake/radeon.json').write_text(json.dumps(d,indent=2)+'\n')
PY
sha256sum /opt/bc250-x11-wake/libvulkan_radeon.so /opt/bc250/lib/libvulkan_radeon.so
