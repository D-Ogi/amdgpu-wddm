#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250-x11-wake/radeon.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true
unset BC250_DIAG_VIEWPORT
set +e
timeout 45 /work/parity002/multi-viewport -auto > /work/parity002/multi-viewport.out 2> /work/parity002/multi-viewport.err
rc=$?; echo "$rc" > /work/parity002/multi-viewport.exit
[ "$rc" = 0 ] || [ "$rc" = 1 ] || exit "$rc"
export BC250_DIAG_VIEWPORT=1
timeout 45 /work/parity002/multi-viewport -auto > /work/parity002/multi-viewport-forced.out 2> /work/parity002/multi-viewport-forced.err
rc=$?; echo "$rc" > /work/parity002/multi-viewport-forced.exit
