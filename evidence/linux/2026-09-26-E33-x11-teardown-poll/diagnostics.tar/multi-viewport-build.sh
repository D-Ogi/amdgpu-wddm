#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
p=Path('/work/src/piglit/tests/glx/glx-multi-window-single-context.c')
s=p.read_text();Path('/work/parity002/multi-original.c').write_text(s)
needle='\t\tglXMakeCurrent(dpy, win[i], ctx);'
extra='''
                GLint vp[4], drawbuf, readbuf;
                glGetIntegerv(GL_VIEWPORT, vp);
                glGetIntegerv(GL_DRAW_BUFFER, &drawbuf);
                glGetIntegerv(GL_READ_BUFFER, &readbuf);
                fprintf(stderr, "window=%d viewport=%d,%d,%d,%d draw=%x read=%x\\n", i, vp[0], vp[1], vp[2], vp[3], drawbuf, readbuf);
                if (getenv("BC250_DIAG_VIEWPORT"))
                   glViewport(0, 0, piglit_width, piglit_height);
'''
assert s.count(needle)==2
p.write_text(s.replace(needle,needle+extra))
Path('/work/parity002/multi-viewport.c').write_text(p.read_text())
PY
ninja -C /work/build/piglit bin/glx-multi-window-single-context
cp /work/build/piglit/bin/glx-multi-window-single-context /work/parity002/multi-viewport
cp /work/parity002/multi-original.c /work/src/piglit/tests/glx/glx-multi-window-single-context.c
ninja -C /work/build/piglit bin/glx-multi-window-single-context
