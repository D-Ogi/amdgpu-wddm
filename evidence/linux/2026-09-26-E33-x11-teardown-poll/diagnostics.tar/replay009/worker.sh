#!/bin/sh
set +e
chroot /mnt/bc250-build/root sh /work/parity002/replay009/run.sh > /mnt/bc250-build/root/work/parity002/replay009/stdout.txt 2> /mnt/bc250-build/root/work/parity002/replay009/stderr.txt
rc=$?
echo "$rc" > /mnt/bc250-build/root/work/parity002/replay009/exit.txt
