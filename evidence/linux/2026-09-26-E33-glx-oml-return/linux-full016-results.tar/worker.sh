#!/bin/sh
set +e
chroot /mnt/bc250-build/root sh /work/parity002/full016/run.sh > /mnt/bc250-build/root/work/parity002/full016/stdout.txt 2> /mnt/bc250-build/root/work/parity002/full016/stderr.txt
rc=$?
echo "$rc" > /mnt/bc250-build/root/work/parity002/full016/exit.txt
