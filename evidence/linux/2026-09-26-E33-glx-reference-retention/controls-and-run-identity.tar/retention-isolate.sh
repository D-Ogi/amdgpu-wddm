#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true
set +e
unset keep_native_window_glx_drawable
timeout 45 /work/build/piglit/bin/gl-1.0-swapbuffers-behavior -auto > /work/parity002/isolate-pre.out 2> /work/parity002/isolate-pre.err
rc=$?;echo "$rc" > /work/parity002/isolate-pre.exit
[ "$rc" = 0 ] || exit "$rc"
export keep_native_window_glx_drawable=true
timeout 45 /work/build/piglit/bin/gl-1.0-swapbuffers-behavior -auto > /work/parity002/isolate-retention.out 2> /work/parity002/isolate-retention.err
rc=$?;echo "$rc" > /work/parity002/isolate-retention.exit
