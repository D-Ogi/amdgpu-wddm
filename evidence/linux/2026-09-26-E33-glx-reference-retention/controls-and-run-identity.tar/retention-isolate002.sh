#!/bin/sh
export DISPLAY=:0 MESA_SHADER_CACHE_DISABLE=true keep_native_window_glx_drawable=true
export VK_DRIVER_FILES=/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json
set +e
for driver in zink radeonsi; do
 export GALLIUM_DRIVER=$driver MESA_LOADER_DRIVER_OVERRIDE=$driver
 if [ "$driver" = zink ]; then export LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib; else export LD_LIBRARY_PATH=/opt/bc250-xorg/lib:/opt/bc250/lib:/opt/piglit/lib/piglit/lib; fi
 timeout 45 /work/parity002/multi-cleanup -auto > /work/parity002/isolate002-$driver.out 2> /work/parity002/isolate002-$driver.err
 rc=$?;echo "$rc" > /work/parity002/isolate002-$driver.exit
 [ "$rc" = 0 ] || exit "$rc"
 export GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
 timeout 45 /work/build/piglit/bin/gl-1.0-swapbuffers-behavior -auto > /work/parity002/isolate002-post-$driver.out 2> /work/parity002/isolate002-post-$driver.err
 rc=$?;echo "$rc" > /work/parity002/isolate002-post-$driver.exit
 [ "$rc" = 0 ] || exit "$rc"
done
