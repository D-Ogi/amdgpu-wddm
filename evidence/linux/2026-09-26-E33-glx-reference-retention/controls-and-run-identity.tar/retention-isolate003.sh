#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true keep_native_window_glx_drawable=true
set +e
timeout 45 /opt/piglit/lib/piglit/bin/glx-multi-window-single-context -auto > /work/parity002/isolate003-original.out 2> /work/parity002/isolate003-original.err
rc=$?;echo "$rc" > /work/parity002/isolate003-original.exit
[ "$rc" = 1 ] || exit "$rc"
timeout 45 /work/build/piglit/bin/gl-1.0-swapbuffers-behavior -auto > /work/parity002/isolate003-post.out 2> /work/parity002/isolate003-post.err
rc=$?;echo "$rc" > /work/parity002/isolate003-post.exit
