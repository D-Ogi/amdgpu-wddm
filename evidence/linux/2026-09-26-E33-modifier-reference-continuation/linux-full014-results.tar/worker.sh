#!/bin/sh
set +e
chroot /mnt/bc250-build/root sh /work/parity002/full014/run.sh > /mnt/bc250-build/root/work/parity002/full014/stdout.txt 2> /mnt/bc250-build/root/work/parity002/full014/stderr.txt
rc=$?
echo "$rc" > /mnt/bc250-build/root/work/parity002/full014/exit.txt
