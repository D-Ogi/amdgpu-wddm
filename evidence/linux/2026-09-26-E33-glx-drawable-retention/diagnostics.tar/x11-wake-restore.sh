#!/bin/sh
set -eu
cd /work/src/mesa-05e6c9622e135ac2aeaf56ec70222642627e2162
patch -R -p1 < /work/parity002/x11-wake.patch
cmp src/vulkan/wsi/wsi_common_x11.c /work/parity002/wsi_common_x11.original.c
ninja -C /work/build/mesa src/amd/vulkan/libvulkan_radeon.so
cmp /work/build/mesa/src/amd/vulkan/libvulkan_radeon.so /opt/bc250/lib/libvulkan_radeon.so
sha256sum /work/build/mesa/src/amd/vulkan/libvulkan_radeon.so
