#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
p=Path('/work/src/piglit/tests/glx/glx-multi-window-single-context.c')
s=p.read_text();assert s == Path('/work/parity002/multi-original.c').read_text()
needle='\t\tpiglit_draw_rect(-1, -1, 2, 2);'
extra='''
                if (getenv("BC250_DIAG_IMMEDIATE")) {
                   unsigned char pixel[4] = {0};
                   glReadPixels(0, 0, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, pixel);
                   fprintf(stderr, "immediate window=%d rgb=%u,%u,%u error=%x\\n", i, pixel[0], pixel[1], pixel[2], glGetError());
                }
                if (getenv("BC250_DIAG_FINISH"))
                   glFinish();
'''
assert s.count(needle)==1
p.write_text(s.replace(needle,needle+extra))
Path('/work/parity002/multi-lifetime.c').write_text(p.read_text())
PY
ninja -C /work/build/piglit bin/glx-multi-window-single-context
cp /work/build/piglit/bin/glx-multi-window-single-context /work/parity002/multi-lifetime
cp /work/parity002/multi-original.c /work/src/piglit/tests/glx/glx-multi-window-single-context.c
ninja -C /work/build/piglit bin/glx-multi-window-single-context
