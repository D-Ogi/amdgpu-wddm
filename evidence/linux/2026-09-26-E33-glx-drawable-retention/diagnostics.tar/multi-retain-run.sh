#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250-x11-wake/radeon.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true
export keep_native_window_glx_drawable=true
set +e
for test in glx-make-current glx-multi-window-single-context; do
 timeout 45 /opt/piglit/lib/piglit/bin/$test -auto > /work/parity002/retain-$test.out 2> /work/parity002/retain-$test.err
 rc=$?;echo "$rc" > /work/parity002/retain-$test.exit
 [ "$rc" = 0 ] || [ "$rc" = 1 ] || exit "$rc"
done
