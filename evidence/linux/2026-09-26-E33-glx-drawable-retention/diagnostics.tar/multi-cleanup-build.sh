#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
p=Path('/work/src/piglit/tests/glx/glx-multi-window-single-context.c')
s=p.read_text();assert s == Path('/work/parity002/multi-original.c').read_text()
assert s.count('glXDestroyWindow(dpy, win[i]);') == 2
p.write_text(s.replace('glXDestroyWindow(dpy, win[i]);','XDestroyWindow(dpy, win[i]);'))
Path('/work/parity002/multi-cleanup.c').write_text(p.read_text())
PY
ninja -C /work/build/piglit bin/glx-multi-window-single-context
cp /work/build/piglit/bin/glx-multi-window-single-context /work/parity002/multi-cleanup
cp /work/parity002/multi-original.c /work/src/piglit/tests/glx/glx-multi-window-single-context.c
ninja -C /work/build/piglit bin/glx-multi-window-single-context
