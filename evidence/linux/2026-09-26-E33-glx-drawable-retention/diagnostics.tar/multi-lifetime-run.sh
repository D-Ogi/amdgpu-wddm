#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250-x11-wake/radeon.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true
set +e
for mode in immediate finish; do
 unset BC250_DIAG_IMMEDIATE BC250_DIAG_FINISH
 if [ "$mode" = immediate ]; then export BC250_DIAG_IMMEDIATE=1; else export BC250_DIAG_FINISH=1; fi
 timeout 45 /work/parity002/multi-lifetime -auto > /work/parity002/multi-lifetime-$mode.out 2> /work/parity002/multi-lifetime-$mode.err
 rc=$?; echo "$rc" > /work/parity002/multi-lifetime-$mode.exit
 [ "$rc" = 0 ] || [ "$rc" = 1 ] || exit "$rc"
done
