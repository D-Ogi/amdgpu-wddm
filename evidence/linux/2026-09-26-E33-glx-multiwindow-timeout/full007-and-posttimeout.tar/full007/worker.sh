#!/bin/sh
set +e
chroot /mnt/bc250-build/root sh /work/parity002/full007/run.sh > /mnt/bc250-build/root/work/parity002/full007/stdout.txt 2> /mnt/bc250-build/root/work/parity002/full007/stderr.txt
rc=$?
echo "$rc" > /mnt/bc250-build/root/work/parity002/full007/exit.txt
