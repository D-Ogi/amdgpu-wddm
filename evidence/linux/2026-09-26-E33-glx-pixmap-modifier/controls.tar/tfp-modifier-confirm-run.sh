#!/bin/sh
export DISPLAY=:0 LD_LIBRARY_PATH=/opt/bc250/lib:/opt/piglit/lib/piglit/lib
export VK_DRIVER_FILES=/opt/bc250/share/vulkan/icd.d/radeon_icd.x86_64.json GALLIUM_DRIVER=zink MESA_LOADER_DRIVER_OVERRIDE=zink MESA_SHADER_CACHE_DISABLE=true keep_native_window_glx_drawable=true
set +e
timeout 45 gdb -nx -batch -x /work/parity002/tfp-modifier-confirm.gdb --args /opt/piglit/lib/piglit/bin/glx-tfp -auto > /work/parity002/tfp-modifier-confirm.log 2>&1
rc=$?;echo "$rc" > /work/parity002/tfp-modifier-confirm.exit
