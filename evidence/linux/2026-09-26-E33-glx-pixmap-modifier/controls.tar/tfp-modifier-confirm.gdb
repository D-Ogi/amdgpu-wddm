set pagination off
set breakpoint pending on
break loader_dri3_get_pixmap_buffer
commands
silent
printf "TFP multiplanes=%d screen_multibuffer=%d\n", multiplanes_available, screen->has_multibuffer
continue
end
break zink_resource_from_handle
commands
silent
printf "TFP modifier=0x%llx stride=%u offset=%u\n", whandle->modifier, whandle->stride, whandle->offset
continue
end
run
