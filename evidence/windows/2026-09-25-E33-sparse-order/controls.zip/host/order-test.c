
#include <windows.h>
#include <d3dkmthk.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#define NT_SUCCESS(s) ((s)>=0)
#define VK_SUCCESS 0
#define VK_ERROR_DEVICE_LOST -4
#define VK_ERROR_OUT_OF_HOST_MEMORY -1
typedef int VkResult;
enum amd_ip_type {AMD_IP_GFX=0};
struct vk_sync_wait {uint64_t wait_value;};
struct radv_winsys_submit_info {enum amd_ip_type ip_type;uint32_t queue_index;};
struct radeon_winsys_ctx {int unused;};
struct radeon_winsys {VkResult (*cs_submit)(struct radeon_winsys_ctx*,const struct radv_winsys_submit_info*,uint32_t,const struct vk_sync_wait*,uint32_t,const void*);};
struct util_dynarray {void *data;unsigned size;};
static void util_dynarray_clear(struct util_dynarray *p){p->size=0;}
static void *util_dynarray_grow_bytes(struct util_dynarray *p,unsigned count,size_t size){
 unsigned old=p->size;p->data=realloc(p->data,old+count*size);assert(p->data);p->size+=(unsigned)(count*size);return (char*)p->data+old;
}
#define util_dynarray_num_elements(p,type) ((p)->size/sizeof(type))
struct vk_wddm2_fence {uint32_t handle;uint64_t wait_value;};
struct radv_wddm2_queue {uint32_t context_h,handle;struct vk_wddm2_fence vm_fence;struct util_dynarray sparse_ops;bool sparse_batch_active;};
struct radv_wddm2_ctx {struct radeon_winsys_ctx base;struct {struct radv_wddm2_queue queue;} per_ip[1];};
struct radv_wddm2_winsys {struct radeon_winsys base;uint32_t device_h;};
struct radv_wddm2_bo {struct {uint64_t va;uint32_t handle;} base;};
static struct radv_wddm2_winsys *radv_wddm2_winsys(struct radeon_winsys *p){return (void*)p;}
enum {APP_WAIT,BOUNDARY,MAP_WAIT,DRAW,APP_SIGNAL};
struct command {unsigned op;uint64_t value;unsigned a,b;};
static struct command stream[64];static unsigned head,tail;
static uint64_t app_value,vm_value,signal_value;
static unsigned pages[2],draws,updates,map_count,wait_calls,hw;
static uint64_t map_wait;
static D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION pending_ops[300];
static void push(unsigned op,uint64_t value,unsigned a,unsigned b){assert(tail<64);stream[tail++]=(struct command){op,value,a,b};}
static void pump(void){
 bool progress;
 do{
  progress=false;
  if(map_count && vm_value>=map_wait){
   for(unsigned i=0;i<map_count;i++){
    D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION *o=&pending_ops[i];
    if(o->OperationType==D3DDDI_UPDATEGPUVIRTUALADDRESS_MAP_PROTECT){
     unsigned page=(unsigned)((o->MapProtect.BaseAddress-0x200000000ull)/65536);
     assert(page<2 && o->MapProtect.SizeInBytes==65536);pages[page]=o->MapProtect.hAllocation;
    }else{
     assert(o->OperationType==D3DDDI_UPDATEGPUVIRTUALADDRESS_UNMAP && o->Unmap.Protection.Zero);
     unsigned page=(unsigned)((o->Unmap.BaseAddress-0x200000000ull)/65536);
     assert(page<2 && o->Unmap.SizeInBytes==65536);pages[page]=0;
    }
   }
   vm_value=map_wait+1;map_count=0;progress=true;
  }
  if(head<tail){
   struct command c=stream[head];
   if(c.op==APP_WAIT && app_value<c.value)continue;
   if(c.op==MAP_WAIT && vm_value<c.value)continue;
   if(c.op==BOUNDARY)vm_value=c.value;
   if(c.op==DRAW){assert(pages[0]==c.a && pages[1]==c.b);draws++;}
   if(c.op==APP_SIGNAL)signal_value=c.value;
   head++;progress=true;
  }
 }while(progress);
}
static VkResult mock_submit(struct radeon_winsys_ctx *ctx,const struct radv_winsys_submit_info *info,
 uint32_t count,const struct vk_sync_wait *waits,uint32_t signals,const void *signal){
 (void)ctx;(void)signal;assert(info->ip_type==AMD_IP_GFX && info->queue_index==0 && signals==0);
 for(unsigned i=0;i<count;i++){push(APP_WAIT,waits[i].wait_value,0,0);wait_calls++;}
 pump();return VK_SUCCESS;
}
static NTSTATUS boundary_signal(uint32_t handle,uint64_t value){
 assert(handle==44);push(BOUNDARY,value,0,0);pump();return 0;
}
static NTSTATUS completion_wait(uint32_t handle,uint64_t value){
 assert(handle==44);push(MAP_WAIT,value,0,0);pump();return 0;
}
static NTSTATUS mock_SignalSynchronizationObjectFromGpu2(const D3DKMT_SIGNALSYNCHRONIZATIONOBJECTFROMGPU2 *p){
 assert(!hw && p->BroadcastContextCount==1 && *p->BroadcastContextArray==22 && p->ObjectCount==1);
 return boundary_signal(*p->ObjectHandleArray,*p->MonitoredFenceValueArray);
}
static NTSTATUS mock_SubmitSignalSyncObjectsToHwQueue(const D3DKMT_SUBMITSIGNALSYNCOBJECTSTOHWQUEUE *p){
 assert(hw && p->BroadcastHwQueueCount==1 && *p->BroadcastHwQueueArray==55 && p->ObjectCount==1);
 return boundary_signal(*p->ObjectHandleArray,*p->FenceValueArray);
}
static NTSTATUS mock_UpdateGpuVirtualAddress(const D3DKMT_UPDATEGPUVIRTUALADDRESS *p){
 assert(!map_count && p->hDevice==33 && p->hContext==22 && p->hFenceObject==44);
 assert(!p->Flags.DoNotWait && p->NumOperations && p->NumOperations<=300);
 assert(p->FenceValue==updates*2+1);
 memcpy(pending_ops,p->Operations,p->NumOperations*sizeof(pending_ops[0]));
 map_count=p->NumOperations;map_wait=p->FenceValue;updates++;pump();return 0;
}
static NTSTATUS mock_WaitForSynchronizationObjectFromGpu(const D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMGPU *p){
 assert(!hw && p->hContext==22 && p->ObjectCount==1);
 return completion_wait(*p->ObjectHandleArray,*p->MonitoredFenceValueArray);
}
static NTSTATUS mock_SubmitWaitForSyncObjectsToHwQueue(const D3DKMT_SUBMITWAITFORSYNCOBJECTSTOHWQUEUE *p){
 assert(hw && p->hHwQueue==55 && p->ObjectCount==1);
 return completion_wait(*p->ObjectHandleArray,*p->FenceValueArray);
}
#define WDDM2_DISPATCH(call) mock_##call
static VkResult
radv_wddm2_virtual_bind_begin(struct radeon_winsys *_ws, struct radeon_winsys_ctx *_ctx,
                             enum amd_ip_type ip_type)
{
   struct radv_wddm2_ctx *ctx = (struct radv_wddm2_ctx *)_ctx;
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;

   /* RADV externally serializes submission to each advertised hardware queue. */
   if (queue->sparse_batch_active || !queue->context_h || !queue->vm_fence.handle)
      return VK_ERROR_DEVICE_LOST;
   util_dynarray_clear(&queue->sparse_ops);
   queue->sparse_batch_active = true;
   return VK_SUCCESS;
}

static VkResult
radv_wddm2_virtual_bind_append(struct radv_wddm2_ctx *ctx, enum amd_ip_type ip_type,
                              const D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION *op)
{
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;
   if (!queue->sparse_batch_active)
      return VK_ERROR_DEVICE_LOST;
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION *dst =
      util_dynarray_grow_bytes(&queue->sparse_ops, 1, sizeof(*op));
   if (!dst)
      return VK_ERROR_OUT_OF_HOST_MEMORY;
   *dst = *op;
   return VK_SUCCESS;
}

static VkResult
radv_wddm2_virtual_bind_end(struct radeon_winsys *_ws, struct radeon_winsys_ctx *_ctx,
                           enum amd_ip_type ip_type, uint32_t queue_index,
                           uint32_t wait_count, const struct vk_sync_wait *waits, bool commit)
{
   struct radv_wddm2_winsys *ws = radv_wddm2_winsys(_ws);
   struct radv_wddm2_ctx *ctx = (struct radv_wddm2_ctx *)_ctx;
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;
   VkResult result = VK_SUCCESS;
   NTSTATUS status;

   if (!queue->sparse_batch_active)
      return VK_ERROR_DEVICE_LOST;
   queue->sparse_batch_active = false;
   if (!commit)
      goto done;

   /* An empty GPU submission queues application waits without a CPU wait.
    * The boundary signal below follows both those waits and earlier rendering.
    */
   const struct radv_winsys_submit_info submit = {
      .ip_type = ip_type,
      .queue_index = queue_index,
   };
   result = _ws->cs_submit(_ctx, &submit, wait_count, waits, 0, NULL);
   if (result != VK_SUCCESS)
      goto done;

   const unsigned count =
      util_dynarray_num_elements(&queue->sparse_ops, D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION);
   if (!count)
      goto done;
   if (queue->vm_fence.wait_value > UINT64_MAX - 2) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }
   const uint64_t boundary = queue->vm_fence.wait_value + 1;
   const uint64_t completed = boundary + 1;
   if (queue->handle) {
      const D3DKMT_SUBMITSIGNALSYNCOBJECTSTOHWQUEUE signal = {
         .BroadcastHwQueueCount = 1,
         .BroadcastHwQueueArray = &queue->handle,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .FenceValueArray = &boundary,
      };
      status = WDDM2_DISPATCH(SubmitSignalSyncObjectsToHwQueue(&signal));
   } else {
      const D3DKMT_SIGNALSYNCHRONIZATIONOBJECTFROMGPU2 signal = {
         .BroadcastContextCount = 1,
         .BroadcastContextArray = &queue->context_h,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .MonitoredFenceValueArray = &boundary,
      };
      status = WDDM2_DISPATCH(SignalSynchronizationObjectFromGpu2(&signal));
   }
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }

   /* WDK26100 D3DKMT_UPDATEGPUVIRTUALADDRESS: wait for FenceValue, then
    * signal FenceValue+1 from the paging companion context. The runtime owns
    * backing residency while these mapping operations are queued.
    */
   const D3DKMT_UPDATEGPUVIRTUALADDRESS update = {
      .hDevice = ws->device_h,
      .hContext = queue->context_h,
      .hFenceObject = queue->vm_fence.handle,
      .FenceValue = boundary,
      .Operations = queue->sparse_ops.data,
      .NumOperations = count,
   };
   status = WDDM2_DISPATCH(UpdateGpuVirtualAddress(&update));
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }

   if (queue->handle) {
      const D3DKMT_SUBMITWAITFORSYNCOBJECTSTOHWQUEUE wait = {
         .hHwQueue = queue->handle,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .FenceValueArray = &completed,
      };
      status = WDDM2_DISPATCH(SubmitWaitForSyncObjectsToHwQueue(&wait));
   } else {
      const D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMGPU wait = {
         .hContext = queue->context_h,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .MonitoredFenceValueArray = &completed,
      };
      status = WDDM2_DISPATCH(WaitForSynchronizationObjectFromGpu(&wait));
   }
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }
   queue->vm_fence.wait_value = completed;

done:
   util_dynarray_clear(&queue->sparse_ops);
   return result;
}

static VkResult
radv_wddm2_virtual_bo_map(struct radv_wddm2_winsys *ws, struct radv_wddm2_ctx *ctx,
                            enum amd_ip_type ip_type, struct radv_wddm2_bo *parent,
                            uint64_t offset, uint64_t size, struct radv_wddm2_bo *bo,
                            uint64_t bo_offset)
{
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION op = {
      .OperationType = D3DDDI_UPDATEGPUVIRTUALADDRESS_MAP_PROTECT,
      .MapProtect = {
         .BaseAddress = parent->base.va + offset,
         .SizeInBytes = size,
         .hAllocation = bo->base.handle,
         .AllocationOffsetInBytes = bo_offset,
         .AllocationSizeInBytes = size,
         .Protection = {
            .Write = 1,
         },
         .DriverProtection = 1,
      },
   };

   return radv_wddm2_virtual_bind_append(ctx, ip_type, &op);
}

static VkResult
radv_wddm2_virtual_bo_unmap(struct radv_wddm2_winsys *ws, struct radv_wddm2_ctx *ctx,
                            enum amd_ip_type ip_type, struct radv_wddm2_bo *parent,
                            uint64_t offset, uint64_t size)
{
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION op = {
      .OperationType = D3DDDI_UPDATEGPUVIRTUALADDRESS_UNMAP,
      .Unmap = {
         .BaseAddress = parent->base.va + offset,
         .SizeInBytes = size,
         .Protection = {
            .Zero = 1,
         }
      },
   };

   return radv_wddm2_virtual_bind_append(ctx, ip_type, &op);
}


static void run_case(unsigned hardware,unsigned already_signaled){
 struct radv_wddm2_winsys ws={0};struct radv_wddm2_ctx ctx={0};
 struct radv_wddm2_queue *q=&ctx.per_ip[0].queue;
 struct radv_wddm2_bo parent={0},a={0},b={0};
 struct vk_sync_wait waits[1]={{5}};
 ws.base.cs_submit=mock_submit;ws.device_h=33;q->context_h=22;q->handle=hardware?55:0;q->vm_fence.handle=44;
 parent.base.va=0x200000000ull;a.base.handle=101;b.base.handle=202;
 head=tail=updates=map_count=draws=wait_calls=0;hw=hardware;
 app_value=already_signaled?5:0;vm_value=signal_value=0;pages[0]=11;pages[1]=22;
 push(DRAW,0,11,22); /* Prior render must see the old mapping. */
 assert(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)==0);
 assert(radv_wddm2_virtual_bo_map(&ws,&ctx,AMD_IP_GFX,&parent,0,65536,&a,0)==0);
 assert(radv_wddm2_virtual_bo_unmap(&ws,&ctx,AMD_IP_GFX,&parent,65536,65536)==0);
 assert(updates==0);
 assert(radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,1,waits,true)==0);
 assert(updates==1 && q->vm_fence.wait_value==2 && wait_calls==1);
 push(DRAW,0,101,0);push(APP_SIGNAL,1,0,0);pump();
 if(!already_signaled){assert(draws==1 && !signal_value && pages[0]==11 && pages[1]==22);}
 app_value=5;pump();assert(draws==2 && signal_value==1 && vm_value==2);
 /* Rebind the same VA with an independently delayed dependency. */
 waits[0].wait_value=7;
 assert(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)==0);
 for(unsigned i=0;i<257;i++)
  assert(radv_wddm2_virtual_bo_map(&ws,&ctx,AMD_IP_GFX,&parent,65536,65536,&b,0)==0);
 assert(radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,1,waits,true)==0);
 assert(updates==2 && q->vm_fence.wait_value==4 && wait_calls==2);
 push(DRAW,0,101,202);push(APP_SIGNAL,2,0,0);pump();
 assert(signal_value==1 && pages[1]==0);
 app_value=7;pump();assert(draws==3 && signal_value==2 && vm_value==4);
 /* Empty transactions still consume their input dependency exactly once. */
 waits[0].wait_value=9;
 assert(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)==0);
 assert(radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,1,waits,true)==0);
 push(APP_SIGNAL,3,0,0);pump();assert(signal_value==2 && updates==2);
 app_value=9;pump();assert(signal_value==3 && wait_calls==3 && q->vm_fence.wait_value==4);
 assert(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)==0);
 assert(radv_wddm2_virtual_bo_unmap(&ws,&ctx,AMD_IP_GFX,&parent,0,65536)==0);
 assert(radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,0,NULL,false)==0);
 pump();assert(updates==2 && pages[0]==101 && head==tail && !q->sparse_batch_active && q->sparse_ops.size==0);
 free(q->sparse_ops.data);
}
int main(void){
 for(unsigned hwq=0;hwq<2;hwq++)for(unsigned signaled=0;signaled<2;signaled++)run_case(hwq,signaled);
 puts("PASS: legacy/HW queues, early/delayed application waits, old/new mapping draws, batch257, fences1-4, empty/cancelled batches");
 return 0;
}
