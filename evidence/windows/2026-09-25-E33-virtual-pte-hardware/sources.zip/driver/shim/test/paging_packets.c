/* SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 */
/*
 * Packet check for driver/shim/bc250_sdma_paging.c (ADR 0008 stage D, docs/design/paging-node.md
 * section 4a): does bc250_sdma_paging_copy()/bc250_sdma_paging_fill() write exactly what
 * bc250_sdma_emit_copy_linear()/emit_fill() would (already checked against AMD's own field macros
 * by driver/shim/test/sdma_copy_packets.c, M95) into a plain caller-owned buffer, and does the room
 * check answer BC250_SDMA_PAGING_INSUFFICIENT - writing nothing - when the buffer is too small for
 * the operation, the shape DXGKDDI_BUILDPAGINGBUFFER needs for STATUS_GRAPHICS_INSUFFICIENT_DMA_BUFFER.
 *
 * What BuildPagingBuffer itself does - resolving a DXGK_OPERATION_VIRTUAL_TRANSFER/VIRTUAL_FILL's
 * virtual addresses through VidMmTranslate(), finding the root through hSystemContext, and the
 * shadow-buffer copy for the DISPATCH_LEVEL submit path - is driver/kmd code with no host harness;
 * this file is the packet-shape half only, the same split sdma_copy_packets.c draws between "the
 * packets are right" (here) and "the hardware ran them" (BC250_ESCAPE_RUN_SDMACOPY on unit A).
 *
 * Links against driver/shim/bc250_sdma_paging.c, bc250_sdma_copy.c, bc250_sdma.c, bc250_ring.c and
 * bc250_nbio.c - the same files driver/kmd/build.ps1 compiles for the miniport (bc250_sdma_paging.c
 * added to that list alongside them) - plus a plain shim backend, the same shape
 * driver/shim/test/sdma_copy_packets.c supplies for the same reason: nothing here calls
 * bc250_sdma_setup()/hw_init(), so the register side of the backend is never exercised.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bc250_sdma_paging.h"
#include "bc250_sdma.h"
#include "bc250_gmc.h"                    /* BC250_EINVAL */
#include "bc250_gfx.h"                    /* BC250_ENOMEM, pulled in the same way bc250_sdma.c pulls it */
#include "navi10_sdma_pkt_open.h"         /* the same imported header bc250_sdma_copy.c builds against */

/* ---------------------------------------------------------------------------------------------
 * A plain shim backend, cut down exactly as sdma_copy_packets.c's: nothing this file runs calls
 * bc250_sdma_setup()/hw_init()/init_golden_registers() or rings a doorbell, so the register and
 * doorbell sides exist only so the link has something to resolve RREG32/WREG32/wdoorbell* to.
 * ------------------------------------------------------------------------------------------- */

/* Reset lifecycle is tested by run_gfx, not this packet/route harness.
 * SDMA now links these symbols; accidental execution here must fail loudly. */
int bc250_gfx_rlc_safe_enter(struct amdgpu_device *adev, bool *requested)
{
    (void)adev;(void)requested;abort();
}
void bc250_gfx_rlc_safe_exit(struct amdgpu_device *adev, bool requested)
{
    (void)adev;(void)requested;abort();
}

static u32 g_regs[1];

/* The device both entry points now take. Static, not a local, for the reason the header spells out
 * (facts M104): struct amdgpu_device is 0x5B00 bytes and a kernel stack is 24 KB. Nothing this file
 * runs reads a field of it; it exists so that ring->adev is a real, non-NULL device. */
static struct amdgpu_device g_adev;

int bc250_shim_mem_alloc(struct amdgpu_device *adev, enum bc250_mem_domain domain, unsigned int size,
                         unsigned int align, struct bc250_mem *out)
{
	(void)adev; (void)domain; (void)size; (void)align;
	memset(out, 0, sizeof(*out));
	return -12;
}

void bc250_shim_mem_free(struct amdgpu_device *adev, struct bc250_mem *m)
{
	(void)adev;
	if (m) memset(m, 0, sizeof(*m));
}

unsigned int bc250_shim_rreg(struct amdgpu_device *adev, unsigned int dword_index)
{
	(void)adev;
	return dword_index < (sizeof(g_regs) / sizeof(g_regs[0])) ? g_regs[dword_index] : 0;
}

void bc250_shim_wreg(struct amdgpu_device *adev, unsigned int dword_index, unsigned int value)
{
	(void)adev;
	if (dword_index < (sizeof(g_regs) / sizeof(g_regs[0])))
		g_regs[dword_index] = value;
}

void bc250_shim_udelay(unsigned int usec) { (void)usec; }
void bc250_shim_wdoorbell64(struct amdgpu_device *adev, unsigned int index, unsigned long long value)
{ (void)adev; (void)index; (void)value; }
void bc250_shim_wdoorbell32(struct amdgpu_device *adev, unsigned int index, unsigned int value)
{ (void)adev; (void)index; (void)value; }

void bc250_shim_log(int level, void *dev, const char *fmt, ...)
{
	va_list ap;
	(void)level; (void)dev;
	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
}

/* ---------------------------------------------------------------------------------------------
 * Expectations
 * ------------------------------------------------------------------------------------------- */

static unsigned int g_checks, g_failures;
static int g_verbose;

static void check(int ok, const char *what)
{
	g_checks++;
	if (ok) {
		if (g_verbose)
			printf("    ok    %s\n", what);
		return;
	}
	g_failures++;
	printf("    FAIL  %s\n", what);
}

static void check_dwords(const u32 *got, const u32 *want, unsigned int count, const char *what)
{
	unsigned int i;
	int ok = 1;

	for (i = 0; i < count; i++)
		if (got[i] != want[i])
			ok = 0;
	check(ok, what);
	if (!ok || g_verbose) {
		for (i = 0; i < count; i++)
			printf("      dw %2u  got 0x%08X  want 0x%08X%s\n", i, got[i], want[i],
			       got[i] != want[i] ? "  <-- mismatch" : "");
	}
}

static int all_zero(const u32 *buf, unsigned int count)
{
	unsigned int i;

	for (i = 0; i < count; i++)
		if (buf[i] != 0)
			return 0;
	return 1;
}

static int all_pattern(const u32 *buf, unsigned int count, u32 pattern)
{
	unsigned int i;

	for (i = 0; i < count; i++)
		if (buf[i] != pattern)
			return 0;
	return 1;
}

#define TEST_BUF_DWORDS 4096

/* ---------------------------------------------------------------------------------------------
 * Case 1: TRANSFER_VIRTUAL of 3 pages (3 * PAGE_SIZE = 12288 bytes) - one packet, well under
 * copy_max_bytes (0x400000).
 * ------------------------------------------------------------------------------------------- */

static void case_transfer_three_pages(void)
{
	static u32 buf[TEST_BUF_DWORDS];
	u64 src = 0x0000002000001000ULL, dst = 0x0000003000002000ULL;
	unsigned int bytes = 3u * 4096u;
	unsigned int written = 0;
	u32 want[7];

	memset(buf, 0, sizeof(buf));

	printf("\n-- TRANSFER_VIRTUAL, 3 pages, %u bytes --\n", bytes);
	check(bc250_sdma_paging_copy(&g_adev, buf, TEST_BUF_DWORDS, src, dst, bytes, &written) == BC250_SDMA_PAGING_OK,
	      "bc250_sdma_paging_copy succeeds with room to spare");
	check(written == 7, "one packet is 7 dwords, same as bc250_sdma_copy_linear_size(bytes)");

	want[0] = SDMA_PKT_HEADER_OP(SDMA_OP_COPY) | SDMA_PKT_HEADER_SUB_OP(SDMA_SUBOP_COPY_LINEAR);
	want[1] = bytes - 1u;
	want[2] = 0;
	want[3] = (u32)(src & 0xFFFFFFFFu);
	want[4] = (u32)(src >> 32);
	want[5] = (u32)(dst & 0xFFFFFFFFu);
	want[6] = (u32)(dst >> 32);
	check_dwords(buf, want, 7, "the packet matches bc250_sdma_emit_copy_linear() field for field");
	check(all_zero(buf + 7, 8), "nothing written past the packet");
}

/* ---------------------------------------------------------------------------------------------
 * Case 2: FILL_VIRTUAL of 2 pages (2 * PAGE_SIZE = 8192 bytes) - one packet.
 * ------------------------------------------------------------------------------------------- */

static void case_fill_two_pages(void)
{
	static u32 buf[TEST_BUF_DWORDS];
	u64 dst = 0x0000004000003000ULL;
	u32 pattern = 0x00000000u;         /* DXGK_OPERATION_VIRTUAL_FILL zeroes a range on this driver */
	unsigned int bytes = 2u * 4096u;
	unsigned int written = 0;
	u32 want[5];

	memset(buf, 0, sizeof(buf));

	printf("\n-- FILL_VIRTUAL, 2 pages, %u bytes --\n", bytes);
	check(bc250_sdma_paging_fill(&g_adev, buf, TEST_BUF_DWORDS, dst, pattern, bytes, &written) == BC250_SDMA_PAGING_OK,
	      "bc250_sdma_paging_fill succeeds with room to spare");
	check(written == 5, "one packet is 5 dwords, same as bc250_sdma_fill_size(bytes)");

	want[0] = SDMA_PKT_HEADER_OP(SDMA_OP_CONST_FILL);
	want[1] = (u32)(dst & 0xFFFFFFFFu);
	want[2] = (u32)(dst >> 32);
	want[3] = pattern;
	want[4] = bytes - 1u;
	check_dwords(buf, want, 5, "the packet matches bc250_sdma_emit_fill() field for field");
	check(all_zero(buf + 5, 10), "nothing written past the packet");
}

/* ---------------------------------------------------------------------------------------------
 * Case 3: insufficient buffer - the room BuildPagingBuffer has left is smaller than the operation,
 * the shape STATUS_GRAPHICS_INSUFFICIENT_DMA_BUFFER needs. Nothing is written either way.
 * ------------------------------------------------------------------------------------------- */

static void case_insufficient(void)
{
	static u32 buf[TEST_BUF_DWORDS];
	u64 src = 0x0000005000000000ULL, dst = 0x0000006000000000ULL;
	unsigned int written = 0;

	memset(buf, 0xCC, sizeof(buf));    /* not zero, so a stray write would be caught either way */

	printf("\n-- insufficient buffer --\n");
	check(bc250_sdma_paging_copy(&g_adev, buf, 3, src, dst, 12288, &written) == BC250_SDMA_PAGING_INSUFFICIENT,
	      "3 dwords of room refuses a 7-dword TRANSFER");
	check(written == 16, "reports the SDMA-aligned dword count the operation needs (7 rounded up to 16)");
	check(all_pattern(buf, TEST_BUF_DWORDS, 0xCCCCCCCCu), "the whole buffer is untouched (still 0xCC)");

	memset(buf, 0xCC, sizeof(buf));
	written = 0;
	check(bc250_sdma_paging_fill(&g_adev, buf, 2, dst, 0, 8192, &written) == BC250_SDMA_PAGING_INSUFFICIENT,
	      "2 dwords of room refuses a 5-dword FILL");
	check(written == 16, "reports the SDMA-aligned dword count the operation needs (5 rounded up to 16)");
	check(all_pattern(buf, TEST_BUF_DWORDS, 0xCCCCCCCCu), "the whole buffer is untouched (still 0xCC)");

	memset(buf, 0xCC, sizeof(buf));
	written = 0;
	check(bc250_sdma_paging_copy(&g_adev, buf, 0, src, dst, 12288, &written) == BC250_SDMA_PAGING_INSUFFICIENT,
	      "zero dwords of room also refuses");
	check(all_pattern(buf, TEST_BUF_DWORDS, 0xCCCCCCCCu), "and still writes nothing");
}

/* ---------------------------------------------------------------------------------------------
 * Case 4: refusals - a bad argument writes nothing and answers EINVAL, not INSUFFICIENT.
 * ------------------------------------------------------------------------------------------- */

static void case_refusals(void)
{
	static u32 buf[TEST_BUF_DWORDS];
	unsigned int written = 0xDEADBEEFu;

	memset(buf, 0, sizeof(buf));

	printf("\n-- refusals --\n");
	check(bc250_sdma_paging_copy(&g_adev, NULL, TEST_BUF_DWORDS, 0x1000, 0x2000, 4096, &written) == BC250_SDMA_PAGING_EINVAL,
	      "bc250_sdma_paging_copy refuses a NULL buffer");
	check(bc250_sdma_paging_copy(NULL, buf, TEST_BUF_DWORDS, 0x1000, 0x2000, 4096, &written) == BC250_SDMA_PAGING_EINVAL,
	      "bc250_sdma_paging_copy refuses a NULL device (M104: the caller's live adev, never a local one)");
	check(bc250_sdma_paging_fill(NULL, buf, TEST_BUF_DWORDS, 0x1000, 0, 4096, &written) == BC250_SDMA_PAGING_EINVAL,
	      "bc250_sdma_paging_fill refuses a NULL device");
	check(bc250_sdma_paging_copy(&g_adev, buf, TEST_BUF_DWORDS, 0x1000, 0x2000, 0, &written) == BC250_SDMA_PAGING_EINVAL,
	      "bc250_sdma_paging_copy refuses 0 bytes");
	check(bc250_sdma_paging_fill(&g_adev, buf, TEST_BUF_DWORDS, 0x1000, 0, 0, &written) == BC250_SDMA_PAGING_EINVAL,
	      "bc250_sdma_paging_fill refuses 0 bytes");
	check(all_zero(buf, TEST_BUF_DWORDS), "none of the refusals wrote anything");
}

/* ------------------------------------------------------------------------------------------- */

static void case_write_ptes(void)
{
	u32 buf[32];
	const u64 values[3] = {0x123450067ULL, 0xABCDE0067ULL, 0};
	unsigned int written, cap;
	/* Golden payload: low/high words remain in OS page order, including an invalid
	 * zero PTE for cleanup. Address/count/opcode come from upstream packet fields. */
	const u32 expected[10] = {
		SDMA_PKT_HEADER_OP(SDMA_OP_WRITE) | SDMA_PKT_HEADER_SUB_OP(SDMA_SUBOP_WRITE_LINEAR),
		0x00002000, 0x00000001, 5,
		0x23450067, 0x00000001, 0xBCDE0067, 0x0000000A, 0, 0
	};
	memset(buf, 0xCC, sizeof(buf));
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,0x100002000ULL,values,3,&written)==BC250_SDMA_PAGING_OK,
	      "scattered PTE WRITE_LINEAR builds");
	check(written==10 && memcmp(buf,expected,sizeof(expected))==0,"PTE packet equals independent golden words");
	check(all_pattern(buf+10,22,0xCCCCCCCCu),"PTE command leaves trailing guard untouched");
	for(cap=0;cap<16;cap++) {
		memset(buf,0xCC,sizeof(buf));
		check(bc250_sdma_paging_write_ptes(&g_adev,buf,cap,0x2000,values,3,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==16,
		      "PTE command respects aligned ring reservation");
		check(all_pattern(buf,32,0xCCCCCCCCu),"PTE insufficient capacity writes nothing");
	}
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,16,0x2000,values,3,&written)==BC250_SDMA_PAGING_OK && written==10,
	      "PTE exact aligned capacity succeeds");
	memset(buf,0xCC,sizeof(buf));
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,0x2001,values,3,&written)==BC250_SDMA_PAGING_EINVAL && !written,"PTE unaligned destination rejected");
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,~(u64)7,values,3,&written)==BC250_SDMA_PAGING_EINVAL,"PTE destination overflow rejected");
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,0x2000,values,0,&written)==BC250_SDMA_PAGING_EINVAL,"PTE empty list rejected");
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,0x2000,values,0x80001,&written)==BC250_SDMA_PAGING_EINVAL,"PTE count field overflow rejected before array read");
	check(bc250_sdma_paging_write_ptes(&g_adev,buf,32,0x2000,NULL,3,&written)==BC250_SDMA_PAGING_EINVAL,"PTE NULL values rejected");
	check(all_pattern(buf,32,0xCCCCCCCCu),"invalid PTE arguments write nothing");
}

/* Synthetic register identifiers for replay, not hardware addresses. */
enum { TEST_REQ_ID = 0x40, TEST_ACK_ID = 0x44 };
static unsigned int test_request_calls;
static unsigned int test_expected_vmid;
static u32 test_invalidate_req(unsigned int vmid, u32 type)
{
	check(vmid==test_expected_vmid && type==0,"invalidate uses selected VMID and flush type0");
	test_request_calls++;
	return 0x13570000u | (1u << vmid); /* opaque encoder witness, not a hardware request constant */
}
static void case_gart_invalidate(void)
{
	static const struct amdgpu_vmhub_funcs funcs = {NULL,test_invalidate_req};
	struct amdgpu_vmhub *hub=&g_adev.vmhub[AMDGPU_GFXHUB(0)];
	u32 buf[32];unsigned int cap,written;
	const u32 write=SDMA_PKT_HEADER_OP(SDMA_OP_SRBM_WRITE)|SDMA_PKT_SRBM_WRITE_HEADER_BYTE_EN(0xfu);
	const u32 poll=SDMA_PKT_HEADER_OP(SDMA_OP_POLL_REGMEM)|SDMA_PKT_POLL_REGMEM_HEADER_FUNC(3);
	const u32 retry=SDMA_PKT_POLL_REGMEM_DW5_RETRY_COUNT(0xfff)|SDMA_PKT_POLL_REGMEM_DW5_INTERVAL(10);
	hub->vm_inv_eng0_req=TEST_REQ_ID;hub->vm_inv_eng0_ack=TEST_ACK_ID;hub->vmhub_funcs=&funcs;
	memset(buf,0xCC,sizeof(buf));test_request_calls=0;
	check(bc250_sdma_paging_invalidate_gart(&g_adev,buf,16,&written)==BC250_SDMA_PAGING_OK && written==15,"GART flush emits15DW within16DW reservation");
	check(test_request_calls==1 && buf[0]==write && buf[1]==TEST_REQ_ID && buf[2]==0x13570001u,"flush writes derived request before polls");
	check(buf[3]==poll && buf[4]==TEST_REQ_ID*4 && buf[5]==0 && buf[6]==0 && buf[7]==0 && buf[8]==retry,"flush includes request read cycle before ACK");
	check(buf[9]==poll && buf[10]==TEST_ACK_ID*4 && buf[11]==0 && buf[12]==1 && buf[13]==1 && buf[14]==retry,"flush waits for VMID0 acknowledge");
	check(all_pattern(buf+15,17,0xCCCCCCCCu),"flush has no extra writes/root changes or trailing corruption");
	for(cap=0;cap<16;cap++) {
		memset(buf,0xCC,sizeof(buf));
		check(bc250_sdma_paging_invalidate_gart(&g_adev,buf,cap,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==16,"flush refuses undersized reservation");
		check(all_pattern(buf,32,0xCCCCCCCCu),"flush refusal writes nothing");
	}
    /* Each context must request and wait for its own ACK, including VMID15.
     * Insufficient capacity may not publish a request or any partial poll. */
    for (test_expected_vmid=0;test_expected_vmid<16;test_expected_vmid++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_invalidate_vmid(&g_adev,buf,16,test_expected_vmid,&written)==BC250_SDMA_PAGING_OK && written==15,"VMID flush fits one reservation");
        check(buf[2]==(0x13570000u|(1u<<test_expected_vmid)) && buf[12]==(1u<<test_expected_vmid) && buf[13]==(1u<<test_expected_vmid),"request and ACK use same VMID");
        check(all_pattern(buf+15,17,0xCCCCCCCCu),"VMID flush preserves tail");
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_invalidate_vmid(&g_adev,buf,15,test_expected_vmid,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==16,"VMID flush requires aligned room");
        check(all_pattern(buf,32,0xCCCCCCCCu),"VMID insufficient writes nothing");
    }
    test_expected_vmid=0;test_request_calls=0;
    check(bc250_sdma_paging_invalidate_vmid(&g_adev,buf,32,16,&written)==BC250_SDMA_PAGING_EINVAL && !written,"out-of-range VMID refused");
    check(bc250_sdma_paging_invalidate_vmid(&g_adev,buf,32,~0u,&written)==BC250_SDMA_PAGING_EINVAL && !written,"large VMID refused before shift");
    check(test_request_calls==0 && all_pattern(buf,32,0xCCCCCCCCu),"invalid VMID never reaches encoder or output");
	hub->vmhub_funcs=NULL;
	check(bc250_sdma_paging_invalidate_gart(&g_adev,buf,32,&written)==BC250_SDMA_PAGING_EINVAL && !written,"uninitialized hub refuses flush construction");
	hub->vmhub_funcs=&funcs;hub->vm_inv_eng0_ack=~0u;
	check(bc250_sdma_paging_invalidate_gart(&g_adev,buf,32,&written)==BC250_SDMA_PAGING_EINVAL,"register-byte address overflow refused");
	check(all_pattern(buf,32,0xCCCCCCCCu),"invalid hub descriptors write nothing");
	hub->vm_inv_eng0_ack=TEST_ACK_ID;hub->vm_inv_eng0_req=SDMA_PKT_SRBM_WRITE_ADDR_addr_mask+1u;
	check(bc250_sdma_paging_invalidate_gart(&g_adev,buf,32,&written)==BC250_SDMA_PAGING_EINVAL,"request outside SRBM register field refused");
	memset(hub,0,sizeof(*hub));
}

static void case_mapped_copy(void)
{
	static const struct amdgpu_vmhub_funcs funcs={NULL,test_invalidate_req};
	struct amdgpu_vmhub *hub=&g_adev.vmhub[AMDGPU_GFXHUB(0)];
	const u64 ptes[2]={0x123450067ULL,0xABCDF0067ULL};
	struct bc250_sdma_paging_mapping map={0x100002000ULL,ptes,2,0x200003000ULL,101,0x300000123ULL,0x300001231ULL,128};
	u32 buf[128];unsigned int written,cap,i;
	const unsigned int barriers[3]={8,40,58},invalidates[2]={18,68};
	hub->vmhub_funcs=&funcs;hub->vm_inv_eng0_req=TEST_REQ_ID;hub->vm_inv_eng0_ack=TEST_ACK_ID;
	memset(buf,0xCC,sizeof(buf));
	check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,96,&map,&written)==BC250_SDMA_PAGING_OK && written==83,"whole two-page mapped transfer emits83DW within96DW reservation");
	check(buf[0]==SDMA_PKT_HEADER_OP(SDMA_OP_WRITE) && buf[1]==0x2000 && buf[2]==1 && buf[3]==3,"transaction starts with two PTE writes");
	check(buf[4]==0x23450067 && buf[5]==1 && buf[6]==0xBCDF0067 && buf[7]==0xA,"transaction preserves scattered mapping values");
	for(i=0;i<3;i++) {
		unsigned int at=barriers[i];
		check(buf[at]==(SDMA_PKT_HEADER_OP(SDMA_OP_FENCE)|SDMA_PKT_FENCE_HEADER_MTYPE(3)) && buf[at+1]==0x3000 && buf[at+2]==2 && buf[at+3]==101+i,"each phase writes its own scratch marker, without interrupt");
		check(buf[at+4]==(SDMA_PKT_HEADER_OP(SDMA_OP_POLL_REGMEM)|SDMA_PKT_POLL_REGMEM_HEADER_FUNC(3)|SDMA_PKT_POLL_REGMEM_HEADER_MEM_POLL(1)) && buf[at+5]==0x3000 && buf[at+6]==2 && buf[at+7]==101+i && buf[at+8]==~0u && buf[at+9]==(SDMA_PKT_POLL_REGMEM_DW5_RETRY_COUNT(0xfff)|SDMA_PKT_POLL_REGMEM_DW5_INTERVAL(4)),"phase barrier polls matching marker with AMD memory-poll fields");
	}
	for(i=0;i<2;i++) {
		unsigned int at=invalidates[i];
		check(buf[at]==(SDMA_PKT_HEADER_OP(SDMA_OP_SRBM_WRITE)|SDMA_PKT_SRBM_WRITE_HEADER_BYTE_EN(0xfu)) && buf[at+1]==TEST_REQ_ID && buf[at+2]==0x13570001u,"map/unmap barriers precede TLB request");
		check(buf[at+4]==TEST_REQ_ID*4 && buf[at+7]==0 && buf[at+10]==TEST_ACK_ID*4 && buf[at+12]==1 && buf[at+13]==1,"both invalidations have reset-cycle and ACK polls");
	}
	check(buf[33]==SDMA_PKT_HEADER_OP(SDMA_OP_COPY) && buf[34]==127 && buf[35]==0 && buf[36]==0x123 && buf[37]==3 && buf[38]==0x1231 && buf[39]==3,"copy uses exact source/destination/count between mapping and cleanup barriers");
	check(buf[50]==SDMA_PKT_HEADER_OP(SDMA_OP_WRITE) && buf[51]==0x2000 && buf[52]==1 && buf[53]==3 && all_zero(buf+54,4),"cleanup clears same slots only after copy fence/poll");
	check(all_pattern(buf+83,45,0xCCCCCCCCu),"whole transaction leaves trailing memory untouched");
	for(cap=0;cap<96;cap++) {
		memset(buf,0xCC,sizeof(buf));
		check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,cap,&map,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==96,"transaction budget includes map/unmap/barriers and align");
		check(all_pattern(buf,128,0xCCCCCCCCu),"no partial transaction on insufficient capacity");
	}
	map.first_sequence=~0u-1u;
	check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL && !written,"marker wrap rejected before publication");
	map.first_sequence=0;
	check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"zero initial marker rejected");
	map.first_sequence=101;map.scratch_mc++;
	check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"unaligned scratch marker refused");
	check(all_pattern(buf,128,0xCCCCCCCCu),"invalid transaction writes nothing");
	memset(hub,0,sizeof(*hub));
}

static void case_ordered_ptes(void)
{
    u64 ptes[512];u32 buf[1056];unsigned int i,count,written,need,at,cap;
    const u64 table=0xF401000000ULL,scratch=0x300400028ULL;
    for(i=0;i<512;i++)ptes[i]=0x1234567800000000ULL+((u64)i<<12)+0x67;
    for(count=1;count<=512;count++) {
        memset(buf,0xCC,sizeof(buf));
        need=(14u+2u*count+15u)&~15u;
        check(bc250_sdma_paging_update_ptes(&g_adev,buf,need,table,ptes,count,scratch,29,&written)==BC250_SDMA_PAGING_OK && written==14+2*count,"ordered PTE update fits exact aligned reservation");
        check(buf[0]==SDMA_PKT_HEADER_OP(SDMA_OP_WRITE) && buf[1]==(u32)table && buf[2]==(u32)(table>>32) && buf[3]==2*count-1,"ordered PTE write preserves address/count");
        for(i=0;i<count;i++)if(buf[4+2*i]!=(u32)ptes[i] || buf[5+2*i]!=(u32)(ptes[i]>>32))break;
        check(i==count,"ordered write preserves every64-bit PTE");
        at=4+2*count;
        check(buf[at]==(SDMA_PKT_HEADER_OP(SDMA_OP_FENCE)|SDMA_PKT_FENCE_HEADER_MTYPE(3)) && buf[at+1]==(u32)scratch && buf[at+2]==(u32)(scratch>>32) && buf[at+3]==29,"PTE data precedes internal noninterrupting fence");
        check(buf[at+4]==(SDMA_PKT_HEADER_OP(SDMA_OP_POLL_REGMEM)|SDMA_PKT_POLL_REGMEM_HEADER_FUNC(3)|SDMA_PKT_POLL_REGMEM_HEADER_MEM_POLL(1)) && buf[at+5]==(u32)scratch && buf[at+6]==(u32)(scratch>>32) && buf[at+7]==29 && buf[at+8]==~0u,"barrier polls matching PTE marker");
        check(all_pattern(buf+written,1056-written,0xCCCCCCCCu),"ordered PTE update leaves tail untouched");
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_update_ptes(&g_adev,buf,need-1,table,ptes,count,scratch,29,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==need && all_pattern(buf,1056,0xCCCCCCCCu),"one DWORD short cannot expose partial PTE write");
    }
    for(cap=0;cap<32;cap++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_update_ptes(&g_adev,buf,cap,table,ptes,2,scratch,29,&written)==BC250_SDMA_PAGING_INSUFFICIENT && all_pattern(buf,1056,0xCCCCCCCCu),"two-PTE transaction refuses every undersized capacity");
    }
    check(bc250_sdma_paging_update_ptes(&g_adev,buf,1056,~7ULL,ptes,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL && !written,"PTE destination overflow refused");
    check(bc250_sdma_paging_update_ptes(&g_adev,buf,1056,table,ptes,2,scratch+1,1,&written)==BC250_SDMA_PAGING_EINVAL,"unaligned scratch refused");
    check(bc250_sdma_paging_update_ptes(&g_adev,buf,1056,table,ptes,2,0,1,&written)==BC250_SDMA_PAGING_EINVAL,"absent scratch refused");
    check(bc250_sdma_paging_update_ptes(&g_adev,buf,1056,table,ptes,2,scratch,0,&written)==BC250_SDMA_PAGING_EINVAL,"zero marker refused");
    check(bc250_sdma_paging_update_ptes(&g_adev,buf,1056,table,NULL,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL,"absent PTE array refused");
    check(all_pattern(buf,1056,0xCCCCCCCCu),"invalid ordered updates leave buffer intact");
}

static void case_staged_pte_copy(void)
{
    u32 buf[64];unsigned int written,cap,src,dst,choice,i,bytes;
    const unsigned int offsets[]={0,1,63,64,255,480,511};
    const unsigned int counts[]={1,2,31,32,128,256,512};
    const u64 base=0x100000000ull,stage=0x100002000ull,marker=0x100003000ull;
    static unsigned char memory[16384],expected[16384];
    for(src=0;src<7;src++)for(dst=0;dst<7;dst++)for(choice=0;choice<7;choice++) {
        unsigned int count=counts[choice];u64 a=base+offsets[src]*8u,b=base+offsets[dst]*8u;
        if(count>512-offsets[src] || count>512-offsets[dst])continue;
        bytes=count*8u;memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_copy_ptes(&g_adev,buf,48,a,b,count,stage,marker,9,&written)==BC250_SDMA_PAGING_OK && written==34,"staged PTE copy reserves both copies and barriers");
        check(buf[0]==SDMA_PKT_HEADER_OP(SDMA_OP_COPY) && buf[1]==bytes-1 && buf[2]==0 && buf[3]==(u32)a && buf[4]==(u32)(a>>32) && buf[5]==(u32)stage && buf[6]==(u32)(stage>>32),"first copy snapshots source into staging");
        check(buf[17]==SDMA_PKT_HEADER_OP(SDMA_OP_COPY) && buf[18]==bytes-1 && buf[19]==0 && buf[20]==(u32)stage && buf[21]==(u32)(stage>>32) && buf[22]==(u32)b && buf[23]==(u32)(b>>32),"second copy writes staged bytes to destination");
        check(buf[7]==(SDMA_PKT_HEADER_OP(SDMA_OP_FENCE)|SDMA_PKT_FENCE_HEADER_MTYPE(3)) && buf[8]==(u32)marker && buf[9]==(u32)(marker>>32) && buf[10]==9 && buf[14]==9 && buf[15]==0xffffffffu,"first phase noninterrupting marker and matching poll");
        check(buf[24]==(SDMA_PKT_HEADER_OP(SDMA_OP_FENCE)|SDMA_PKT_FENCE_HEADER_MTYPE(3)) && buf[25]==(u32)marker && buf[26]==(u32)(marker>>32) && buf[27]==10 && buf[31]==10 && buf[32]==0xffffffffu,"second phase uses distinct fresh marker");
        check(buf[11]==buf[28] && (buf[11]&0xffu)==SDMA_OP_POLL_REGMEM && buf[12]==(u32)marker && buf[13]==(u32)(marker>>32) && buf[29]==buf[12] && buf[30]==buf[13] && buf[16]==buf[33],"both barriers poll the marker slot");
        check(all_pattern(buf+34,30,0xCCCCCCCCu),"PTE transaction leaves tail guards unchanged");
        for(i=0;i<sizeof(memory);i++)memory[i]=(unsigned char)(i*17u+i/256u);
        memcpy(expected,memory,sizeof(memory));
        memmove(expected+(size_t)(b-base),expected+(size_t)(a-base),bytes);
        // Interpret only the two validated copy payloads; barrier timing is not
        // modeled. Each actual memcpy is disjoint; oracle uses one memmove.
        memcpy(memory+buf[5],memory+buf[3],buf[1]+1u);
        memcpy(memory+buf[22],memory+buf[20],buf[18]+1u);
        check(memcmp(memory,expected,4096)==0,"encoded staged copies match snapshot oracle for overlap and self-copy");
    }
    for(cap=0;cap<48;cap++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_copy_ptes(&g_adev,buf,cap,base,base+8,32,stage,marker,9,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==48 && all_pattern(buf,64,0xCCCCCCCCu),"every undersized capacity refuses whole staged copy");
    }
    memset(buf,0xCC,sizeof(buf));
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,0,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL && !written,"empty PTE copy rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,513,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"more than one table rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base+1,base+8,1,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"unaligned PTE address rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,1,stage+8,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"unaligned staging page rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,stage+4000,base+8,1,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"any staging-page source alias rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,stage+4000,1,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"any staging-page destination alias rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,2,stage,base+12,9,&written)==BC250_SDMA_PAGING_EINVAL,"marker destination alias rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,1,stage,stage+4092,9,&written)==BC250_SDMA_PAGING_EINVAL,"marker staging alias rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,~0ull-7,base,2,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"source end overflow rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,~0ull-7,2,stage,marker,9,&written)==BC250_SDMA_PAGING_EINVAL,"destination end overflow rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,1,stage,marker,0,&written)==BC250_SDMA_PAGING_EINVAL,"zero marker rejected");
    check(bc250_sdma_paging_copy_ptes(&g_adev,buf,64,base,base+8,1,stage,marker,~0u,&written)==BC250_SDMA_PAGING_EINVAL,"marker wrap rejected");
    check(all_pattern(buf,64,0xCCCCCCCCu),"invalid staged-copy inputs never modify output");
}

static void case_staged_byte_copy(void)
{
    const u64 base=0x100000000ull,stage=0x100002000ull,marker=0x100003000ull;
    const unsigned offsets[]={0,1,3,7,8,31,63,4093,4095};
    const unsigned sizes[]={1,2,3,7,8,17,63,511,4095,4096};
    static unsigned char memory[16384],expected[16384];
    u32 buf[64];unsigned a,b,n,i,bytes,written,cap;
    for(a=0;a<9;a++)for(b=0;b<9;b++)for(n=0;n<10;n++) {
        u64 src=base+offsets[a],dst=base+offsets[b];bytes=sizes[n];
        if(bytes>4096-offsets[a] || bytes>4096-offsets[b])continue;
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_copy_bytes(&g_adev,buf,48,src,dst,bytes,stage,marker,21,&written)==BC250_SDMA_PAGING_OK && written==34,"staged arbitrary byte range accepted atomically");
        check(buf[1]+1==bytes && buf[18]+1==bytes && buf[3]==offsets[a] && buf[22]==offsets[b] &&
              buf[5]==8192 && buf[20]==8192 && buf[4]==1 && buf[23]==1,"staged byte packet source stage destination and size match request");
        check(buf[10]==21 && buf[14]==21 && buf[27]==22 && buf[31]==22,"staged byte barriers use two matching distinct markers");
        check(all_pattern(buf+34,30,0xCCCCCCCCu),"staged byte packet tail guard");
        for(i=0;i<sizeof(memory);i++)memory[i]=(unsigned char)(i*37u+i/123u);
        memcpy(expected,memory,sizeof(memory));memmove(expected+offsets[b],expected+offsets[a],bytes);
        memcpy(memory+buf[5],memory+buf[3],buf[1]+1);
        memcpy(memory+buf[22],memory+buf[20],buf[18]+1);
        check(memcmp(memory,expected,8192)==0,"decoded staged bytes match independent overlap snapshot");
    }
    for(cap=0;cap<48;cap++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_copy_bytes(&g_adev,buf,cap,base+1,base+3,17,stage,marker,21,&written)==BC250_SDMA_PAGING_INSUFFICIENT && written==48 && all_pattern(buf,64,0xCCCCCCCCu),"all short capacities refuse before partial staged-byte emission");
    }
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,base,base,0,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL && !written,"zero byte staging refuses");
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,base,base,4097,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL,"staging capacity overrun refuses");
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,~0ull,base,2,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL,"staged byte source wrap refuses");
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,base,~0ull,2,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL,"staged byte destination wrap refuses");
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,stage+4095,base,1,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL,"single byte source alias of reserved stage refuses");
    check(bc250_sdma_paging_copy_bytes(&g_adev,buf,64,base,marker+3,1,stage,marker,21,&written)==BC250_SDMA_PAGING_EINVAL,"single byte destination alias of marker refuses");
}

static void case_mapped_staging(void)
{
    static const struct amdgpu_vmhub_funcs funcs={NULL,test_invalidate_req};
    struct amdgpu_vmhub* hub=&g_adev.vmhub[AMDGPU_GFXHUB(0)];
    struct bc250_sdma_paging_mapping map={0};u64 ptes[2]={0x123450067ull,0x123450067ull};
    u32 buf[128];unsigned written,cap,i;unsigned char memory[16384],expected[16384];
    hub->vmhub_funcs=&funcs;hub->vm_inv_eng0_req=TEST_REQ_ID;hub->vm_inv_eng0_ack=TEST_ACK_ID;
    map.table_mc=0x600000000ull;map.ptes=ptes;map.page_count=2;map.scratch_mc=0x500000000ull;
    map.first_sequence=101;map.src_mc=0x300000001ull;map.dst_mc=0x300001003ull;
    map.bytes=127;map.staging_mc=0x400000000ull;
    memset(buf,0xCC,sizeof(buf));
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,112,&map,&written)==BC250_SDMA_PAGING_OK && written==100,"mapped staged copy reserves complete100-DWORD transaction");
    check(buf[36]==1 && buf[37]==3 && buf[38]==0 && buf[39]==4 && buf[53]==0 && buf[54]==4 && buf[55]==4099 && buf[56]==3,
          "mapped stage captures two disjoint COPY payloads through retained GART slots");
    check(buf[11]==101 && buf[43]==102 && buf[60]==103 && buf[78]==104 && buf[47]==102 && buf[64]==103 && buf[82]==104,
          "map snapshot destination and cleanup phases have four fresh matching markers");
    check(buf[71]==0 && buf[72]==0 && buf[73]==0 && buf[74]==0 && all_pattern(buf+100,28,0xCCCCCCCCu),
          "mapped PTE cleanup occurs after second copy and leaves tail guard");
    for(i=0;i<sizeof(memory);i++)memory[i]=(unsigned char)(i*31+i/257);
    memcpy(expected,memory,sizeof(memory));memmove(expected+3,expected+1,127);
    // Both PTEs name the same physical page; translate slot offsets independently.
    memcpy(memory+8192,memory+buf[36],buf[34]+1);
    memcpy(memory+buf[55]-4096,memory+8192,buf[51]+1);
    check(memcmp(memory,expected,8192)==0,"mapped alias staged bytes match physical memmove oracle");
    for(cap=0;cap<112;cap++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,cap,&map,&written)==BC250_SDMA_PAGING_INSUFFICIENT &&
              written==112 && all_pattern(buf,128,0xCCCCCCCCu),"short mapped-stage capacity refuses before PTE writes");
    }
    map.staging_mc=map.table_mc;
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL && !written,"stage cannot alias GART table storage");
    map.staging_mc=map.scratch_mc;
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"stage cannot alias synchronization marker");
    map.staging_mc=0x300000000ull;
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"stage cannot alias source window range");
    map.staging_mc=0x400000000ull;map.first_sequence=~0u-2;
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"four-phase marker wrap refuses");
    map.first_sequence=101;map.bytes=4097;
    check(bc250_sdma_paging_mapped_transfer(&g_adev,buf,128,&map,&written)==BC250_SDMA_PAGING_EINVAL,"mapped stage refuses oversized snapshot");
    memset(hub,0,sizeof(*hub));
}

static void case_aperture_packets(void)
{
    static const struct amdgpu_vmhub_funcs funcs={NULL,test_invalidate_req};
    struct amdgpu_vmhub* hub=&g_adev.vmhub[AMDGPU_GFXHUB(0)];
    static const unsigned counts[]={1,2,7,16,31,128,480,497,512};
    u32 buf[1088],reference[1088],flush[16];u64 ptes[512];
    const u64 table=0x400020010ull,scratch=0x500000000ull,limit=0x1000000000000ull;
    unsigned i,j,count,need,written,updateWords,flushWords,cap;
    hub->vmhub_funcs=&funcs;hub->vm_inv_eng0_req=TEST_REQ_ID;hub->vm_inv_eng0_ack=TEST_ACK_ID;
    test_expected_vmid=0;
    for(i=0;i<512;i++)ptes[i]=(0x12345000ull+(u64)i*8192)|0x73;
    for(i=0;i<sizeof(counts)/sizeof(counts[0]);i++) {
        count=counts[i];need=(29+2*count+15)&~15u;updateWords=flushWords=0;
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_set_aperture(&g_adev,buf,need,table,ptes,count,scratch,91,&written)==BC250_SDMA_PAGING_OK &&
              written==29+2*count,"aperture writes and invalidation fit complete aligned reservation");
        check(bc250_sdma_paging_update_ptes(&g_adev,reference,1088,table,ptes,count,scratch,91,&updateWords)==BC250_SDMA_PAGING_OK &&
              bc250_sdma_paging_invalidate_gart(&g_adev,flush,16,&flushWords)==BC250_SDMA_PAGING_OK,
              "independent update and GART flush constructors provide positive controls");
        check(written==updateWords+flushWords && memcmp(buf,reference,updateWords*4)==0 &&
              memcmp(buf+updateWords,flush,flushWords*4)==0,
              "aperture transaction is exact ordered update then VMID0 flush");
        for(j=0;j<count;j++)
            check((((u64)buf[5+j*2]<<32)|buf[4+j*2])==ptes[j],"aperture payload preserves each scattered PTE");
        check(all_pattern(buf+written,1088-written,0xCCCCCCCCu),"aperture transaction preserves output tail");
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_set_aperture(&g_adev,buf,need-1,table,ptes,count,scratch,91,&written)==BC250_SDMA_PAGING_INSUFFICIENT &&
              written==need && all_pattern(buf,1088,0xCCCCCCCCu),"aperture short reservation exposes no partial update");
    }
    for(cap=0;cap<48;cap++) {
        memset(buf,0xCC,sizeof(buf));
        check(bc250_sdma_paging_set_aperture(&g_adev,buf,cap,table,ptes,2,scratch,91,&written)==BC250_SDMA_PAGING_INSUFFICIENT &&
              written==48 && all_pattern(buf,1088,0xCCCCCCCCu),"every short two-page aperture buffer stays untouched");
    }
    for(i=0;i<4;i++)ptes[i]=0x98765073ull;
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,48,table,ptes,4,scratch,~0u,&written)==BC250_SDMA_PAGING_OK &&
          buf[4]==0x98765073u && buf[6]==buf[4] && buf[8]==buf[4] && buf[10]==buf[4],
          "unmap payload can repeat a nonzero dummy page with final nonzero marker");
    memset(buf,0xCC,sizeof(buf));
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,ptes,2,table,1,&written)==BC250_SDMA_PAGING_EINVAL && !written,
          "aperture marker cannot overwrite PTE payload");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,ptes,2,table+12,1,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture marker cannot overlap final PTE half");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,limit-8,ptes,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture PTE address cannot cross48bit end");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,ptes,2,limit,1,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture marker must be representable");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table+1,ptes,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture table alignment checked");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,ptes,2,scratch,0,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture marker must be nonzero");
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,NULL,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL,
          "aperture unmap cannot accidentally substitute zero PTEs for dummy page");
    hub->vmhub_funcs=NULL;
    check(bc250_sdma_paging_set_aperture(&g_adev,buf,1088,table,ptes,2,scratch,1,&written)==BC250_SDMA_PAGING_EINVAL &&
          !written && all_pattern(buf,1088,0xCCCCCCCCu),"invalid aperture transactions write nothing including absent flush context");
    memset(hub,0,sizeof(*hub));
}

int main(int argc, char **argv)
{
	int i;

	for (i = 1; i < argc; i++)
		if (strcmp(argv[i], "-v") == 0)
			g_verbose = 1;

	printf("Paging node packets (ADR 0008 stage D): driver/shim/bc250_sdma_paging.c against\n");
	printf("bc250_sdma_emit_copy_linear()/emit_fill() (driver/shim/bc250_sdma_copy.c, M95), dword for\n");
	printf("dword, plus the room check BuildPagingBuffer's STATUS_GRAPHICS_INSUFFICIENT_DMA_BUFFER needs.\n");

	case_transfer_three_pages();
	case_fill_two_pages();
	case_insufficient();
	case_refusals();
	case_write_ptes();
	case_ordered_ptes();
	case_aperture_packets();
	case_staged_pte_copy();
	case_staged_byte_copy();
	case_mapped_staging();
	case_gart_invalidate();
	case_mapped_copy();

	printf("\n== verdict ==\n");
	printf("  %u checks, %u failures\n", g_checks, g_failures);
	printf("  %s\n", g_failures == 0 ? "PASS" : "FAIL");
	return g_failures == 0 ? 0 : 1;
}
