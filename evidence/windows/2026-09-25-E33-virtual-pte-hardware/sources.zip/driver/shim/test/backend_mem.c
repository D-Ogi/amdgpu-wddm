/* SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 */
/*
 * The other half of the host replay backend: memory, doorbells, and a CP stub.
 *
 * backend_trace.c answers register reads and records register writes. This file answers the three
 * calls the GFX and SDMA bring-up makes that are not register access:
 *
 *   bc250_shim_mem_alloc / _free   VRAM and GART-mapped system pages. Here they are host malloc
 *                                  with an MC address handed out of a bump arena, so that every
 *                                  address the shim programs into a register is an address this
 *                                  file chose and the test can check it against what it expects
 *                                  instead of against the trace.
 *   bc250_shim_wdoorbell64         the only way a GFX10 compute or KIQ ring can be told its write
 *                                  pointer. Recorded, and handed to the CP stub.
 *
 * ---------------------------------------------------------------------------------------------
 * The CP stub, declared plainly because it is the one place this replay pretends to be hardware.
 *
 * gfx_v10_0_ring_test_ring() writes 0xCAFEDEAD to SCRATCH_REG0, submits a three-dword PM4 packet
 * that sets the same register to 0xDEADBEEF, rings the doorbell and polls. On unit A the CP
 * executed the packet; against a replayed register file nothing would ever change the value and
 * every one of the eleven ring tests in the window would time out, which would stop the sequence at
 * the first one.
 *
 * So this file executes that one packet, and only that one: on a doorbell it decodes the dwords the
 * ring grew by, and a PACKET3_SET_UCONFIG_REG of one register is applied to the register file
 * through backend_poke() - not through bc250_shim_wreg(), so it can never appear in the comparison
 * as if the shim had written it. Every other packet is logged and otherwise ignored.
 *
 * That makes the ring tests pass for the right reason and not by decree: if the shim built the
 * packet wrongly - wrong opcode, wrong register offset, wrong count, or wrote it at the wrong place
 * in the ring - the stub would not find it, the poll would time out, and the test would fail. The
 * control run turns the stub off and must fail, which is what says the tests were being driven by
 * the packets all along.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "backend_mem.h"
#include "backend_trace.h"

/* AMD's PM4 definitions, imported unmodified, so the decoder uses the same opcode numbers the
 * encoder does. Same rule for the interrupt client and source ids the end-of-pipe delivery below
 * puts into a vector: they come from AMD's headers, not from numbers typed here. */
#include "nvd.h"
#include "soc15_ih_clientid.h"
#include "irqsrcs_gfx_10_1.h"
#include "irqsrcs_sdma0_5_0.h"
#include "irqsrcs_sdma1_5_0.h"
#include "navi10_sdma_pkt_open.h"       /* the SDMA opcodes the second stub below decodes */
#include <navi10_enum.h>                /* CACHE_FLUSH_AND_INV_TS_EVENT */
#include "gc/gc_10_1_0_offset.h"        /* mmCPC_INT_STATUS, and the COMPUTE_* the dispatch sets */
#include "gc/gc_10_1_0_sh_mask.h"       /* GRBM_GFX_CNTL's fields, to read a selection back */
#include "soc15_common.h"               /* SOC15_REG_OFFSET() */

/* libdrm's gfx10 shader binaries, imported unmodified (third_party/libdrm/PROVENANCE.md). The stub
 * refuses to run a dispatch whose program address does not point at these exact words, which is how
 * a host run checks that the driver copied the shader and shifted its address correctly. The
 * `struct reg_info` the file's other tables need is libdrm's, from tests/amdgpu/shader_code.h:56-59;
 * see the same note in driver/shim/bc250_dispatch.c. */
struct reg_info {
	uint32_t reg_offset;
	uint32_t reg_value;
};
#include "shader_code_gfx10.h"

/* ---------------------------------------------------------------------------------------------
 * The three dwords of a fence that unit A's own Linux driver pins
 *
 * Until E13 the stub checked the shape of a fence packet - opcode, count, DATA_SEL, INT_SEL - and
 * nothing else, so a wrong cache-flush event or a fence aimed at the wrong register would have gone
 * through. amdgpu on unit A emits these three words and no others, in three boots:
 *
 *   evidence/linux/2026-09-21-E13-reference-2/boot3-readonly/rings-after-ib/
 *       amdgpu_ring_gfx_0.0.0.txt        dw 0x0511 and 0x0611
 *       amdgpu_ring_comp_1.<p>.<q>.txt   dw 0x010C and 0x020C, all eight rings
 *           c0064900 06603514 22000000 <addr_lo> 00000000 <seq> 00000000 00000000
 *       amdgpu_ring_kiq_0.2.1.0.txt      dw 0x0709 and 0x0E09, the interrupting fences only
 *           c0033700 00100000 000030b5 00000000 20000000
 *
 * They are written here as the expressions that produce them, out of AMD's own headers, so that the
 * check cannot drift away from the encoder by way of a constant typed twice. The comments give the
 * value each one has on this chip; the compiler, not this file, decides it. */
#define FENCE_RELEASE_MEM_CNTL                                                  \
	((u32)(PACKET3_RELEASE_MEM_GCR_SEQ |                                    \
	       PACKET3_RELEASE_MEM_GCR_GL2_WB |                                 \
	       PACKET3_RELEASE_MEM_GCR_GLM_INV |                                \
	       PACKET3_RELEASE_MEM_GCR_GLM_WB |                                 \
	       PACKET3_RELEASE_MEM_CACHE_POLICY(3) |                            \
	       PACKET3_RELEASE_MEM_EVENT_TYPE(CACHE_FLUSH_AND_INV_TS_EVENT) |   \
	       PACKET3_RELEASE_MEM_EVENT_INDEX(5)))           /* 06603514 */

/* The two WRITE_DATA control dwords the KIQ fence builds: to memory for the sequence number, to a
 * register for the interrupt. ENGINE_SEL(0) contributes nothing and is kept because the encoder
 * writes it. */
#define FENCE_WRITE_DATA_CNTL_MEM                                               \
	((u32)(WRITE_DATA_ENGINE_SEL(0) | WRITE_DATA_DST_SEL(5) | WR_CONFIRM))  /* 00100500 */
#define FENCE_WRITE_DATA_CNTL_REG                                               \
	((u32)(WRITE_DATA_ENGINE_SEL(0) | WRITE_DATA_DST_SEL(0) | WR_CONFIRM))  /* 00100000 */

#define MAX_ALLOCS   64u
#define MAX_RINGS    16u
/* Enough for the whole window: the clear-state stream alone is about forty packets. */
#define MAX_PACKETS  256u

struct allocation {
	void *cpu;
	u64   mc;
	u32   size;
};

static struct allocation g_alloc[MAX_ALLOCS];
static unsigned int g_alloc_count;

static u64 g_vram_base, g_vram_next;
static u64 g_gtt_base, g_gtt_next;

struct ring_slot {
	struct amdgpu_ring *ring;
	u64 decoded_to;                 /* how far into the ring the stub has looked, in dwords */
	int dead;                       /* the MEC model faulted on this ring: it executes nothing */

	/* This queue's own CP_HQD_PQ_RPTR, for the MEC model to answer reads with. It is hardware
	 * state, not ring state: it outlives the ring buffer it counted into, which is the whole
	 * point of modelling it, so backend_ring_register() must not clear it. */
	u32 hqd_rptr;
	int hqd_known;                  /* 0 = never ran, so the register file answers as before */

	/* This queue's own CP_HQD_ACTIVE, for the same reason: MAP_QUEUES sets it, UNMAP_QUEUES
	 * clears it, and bc250_kcq_clear_pointers() reads it before it touches a queue's pointers.
	 * Compute queues only - the KIQ's is programmed through the register and stays in the file. */
	int hqd_mapped;
	int hqd_mapped_known;
	int hqd_pinned;                 /* a test asked this queue not to answer an unmap */

	/* An SDMA engine's own write pointer, in BYTES, and whether it has executed anything. The
	 * fifth declared model; backend_mem.h says what E15 measured. Hardware state, not ring
	 * state: it outlives the ring buffer it counted into and the halt that stopped it, so
	 * backend_ring_register() must not clear it either. */
	u64 sdma_engine_ptr;
	int sdma_ran;
	u64 sdma_held_back;             /* a test asked this engine to answer rptr this far behind */
};

static struct ring_slot g_ring[MAX_RINGS];
static unsigned int g_ring_count;

static unsigned int g_doorbells;
static unsigned int g_stub_hits;
static unsigned int g_stub_rejects;
static u32 g_scratch_reg0_dword;        /* set by backend_cp_stub_expect(), 0 = not told yet */
static int g_stub_on = 1;
static unsigned int g_ib_followed;      /* indirect buffers the stub fetched and ran, and those it */
static unsigned int g_ib_skipped;       /* saw at a VMID it has no address space for */
static int g_ib_depth;                  /* 1 while the packets of an IB are being executed */

static struct backend_packet g_packet[MAX_PACKETS];
static unsigned int g_packet_count;

/* Every doorbell, with the width of the store. The width is recorded because it is the one thing
 * about a doorbell a register trace can never show and upstream is specific about: the IH ring's
 * read pointer is a 32-bit store and everything else on this part is 64-bit. See bc250_shim.h. */
#define MAX_DOORBELLS 64u
static struct backend_doorbell g_doorbell[MAX_DOORBELLS];

/* The interrupt ring the stub delivers end-of-pipe vectors into, when a test has attached one. NULL
 * for every run that is only about register writes, which is all of replay_gfx.c. */
static struct amdgpu_device *g_ih_adev;
static u32 g_ih_wptr;                   /* byte offset, the stub's own copy of the hardware's */
static unsigned int g_ih_delivered;
static u64 g_ih_timestamp;

void backend_mem_set_bases(u64 vram_base, u64 gtt_base)
{
	g_vram_base = g_vram_next = vram_base;
	g_gtt_base = g_gtt_next = gtt_base;
}

static void mec_model_off(void);        /* the MEC model, further down; reset turns it off */
static void sdma_model_off(void);       /* the SDMA pointer model, likewise */
static void hooks_refresh(void);        /* the two chained hooks, on while any model is */
static void cs_state_clear(void);       /* the compute dispatch stub's state, likewise */

void backend_mem_reset(void)
{
	unsigned int i;

	mec_model_off();
	sdma_model_off();
	for (i = 0; i < g_alloc_count; i++)
		free(g_alloc[i].cpu);
	g_alloc_count = 0;
	g_vram_next = g_vram_base;
	g_gtt_next = g_gtt_base;

	g_ring_count = 0;
	g_doorbells = 0;
	g_stub_hits = 0;
	g_stub_rejects = 0;
	g_packet_count = 0;
	g_ib_followed = 0;
	g_ib_skipped = 0;
	g_ib_depth = 0;
	cs_state_clear();

	g_ih_adev = NULL;
	g_ih_wptr = 0;
	g_ih_delivered = 0;
	g_ih_timestamp = 0;
}

void backend_ring_register(struct amdgpu_ring *ring)
{
	unsigned int i;

	/* Idempotent by ring, because a teardown and a fresh setup hand back the same ring objects
	 * with new buffers behind them: a second entry would leave the stub reading the first one's
	 * decoded_to and looking at a ring that no longer exists.
	 *
	 * What is NOT cleared here is the hardware state the models keep - this queue's read pointer,
	 * this engine's write pointer - because a new ring buffer is not a new engine. That is the
	 * whole point of both models; see the two blocks in backend_mem.h. */
	for (i = 0; i < g_ring_count; i++) {
		if (g_ring[i].ring == ring) {
			g_ring[i].decoded_to = 0;
			g_ring[i].dead = 0;
			return;
		}
	}

	if (g_ring_count >= MAX_RINGS) {
		fprintf(stderr, "backend_mem: more than %u rings, raise MAX_RINGS\n", MAX_RINGS);
		exit(2);
	}
	g_ring[g_ring_count].ring = ring;
	g_ring[g_ring_count].decoded_to = 0;
	g_ring[g_ring_count].dead = 0;
	g_ring_count++;
}

/* The CPU side of an MC address, if `size` bytes from it lie inside one allocation this file handed
 * out. NULL otherwise, which is how the stub refuses a packet pointing somewhere the GPU could not
 * have written. Linear: there are at most a few dozen allocations. */
static void *mc_to_cpu(u64 mc, u32 size)
{
	unsigned int i;

	for (i = 0; i < g_alloc_count; i++) {
		if (mc >= g_alloc[i].mc && mc + size <= g_alloc[i].mc + g_alloc[i].size)
			return (char *)g_alloc[i].cpu + (size_t)(mc - g_alloc[i].mc);
	}
	return NULL;
}

unsigned int backend_doorbell_count(void) { return g_doorbells; }
const struct backend_doorbell *backend_doorbells(void) { return g_doorbell; }

static void doorbell_record(unsigned int index, unsigned long long value, unsigned int width)
{
	if (g_doorbells < MAX_DOORBELLS) {
		g_doorbell[g_doorbells].index = index;
		g_doorbell[g_doorbells].value = value;
		g_doorbell[g_doorbells].width = width;
	}
	g_doorbells++;
}

/* amdgpu's WDOORBELL32. No CP ring is rung this way, so there is nothing to decode: the only caller
 * on this part is bc250_ih_set_rptr(), and what the test checks is that it was 32 bits wide. */
void bc250_shim_wdoorbell32(struct amdgpu_device *adev, unsigned int index, unsigned int value)
{
	(void)adev;
	doorbell_record(index, value, 32);
}
unsigned int backend_cp_stub_count(void)  { return g_stub_hits; }
unsigned int backend_packet_count(void)   { return g_packet_count; }
void backend_cp_stub_enable(int on)       { g_stub_on = on; }
const struct backend_packet *backend_packets(void) { return g_packet; }

/* --- the memory backend ---------------------------------------------------------------------- */

int bc250_shim_mem_alloc(struct amdgpu_device *adev, enum bc250_mem_domain domain,
			 unsigned int size, unsigned int align, struct bc250_mem *out)
{
	u64 *next;
	void *cpu;

	(void)adev;

	if (out == NULL || size == 0)
		return -22;                             /* -EINVAL, as bc250_gmc.h spells it */
	if (g_alloc_count >= MAX_ALLOCS) {
		fprintf(stderr, "backend_mem: more than %u allocations, raise MAX_ALLOCS\n", MAX_ALLOCS);
		exit(2);
	}
	if (align == 0)
		align = 4;

	next = (domain == BC250_MEM_VRAM) ? &g_vram_next : &g_gtt_next;
	*next = (*next + align - 1u) & ~((u64)align - 1u);

	/* Zeroed, because both the kernel's buffer objects and the miniport's allocations are: the
	 * MQD builders assume every field they do not set is already 0. */
	cpu = calloc(1, size);
	if (cpu == NULL)
		return -12;                             /* -ENOMEM */

	out->cpu = cpu;
	out->mc = *next;
	out->size = size;
	*next += size;

	g_alloc[g_alloc_count].cpu = cpu;
	g_alloc[g_alloc_count].mc = out->mc;
	g_alloc[g_alloc_count].size = size;
	g_alloc_count++;
	return 0;
}

void bc250_shim_mem_free(struct amdgpu_device *adev, struct bc250_mem *m)
{
	unsigned int i;

	(void)adev;
	/* A zeroed struct is a safe no-op, as before. An allocation whose cpu is NULL still exists in
	 * g_alloc and is looked up by its MC address instead (D-02); this backend's own alloc() above
	 * never returns success with cpu == NULL, so the arm is not reached by anything but the fault
	 * suite's model of it. */
	if (m == NULL || (m->cpu == NULL && m->mc == 0 && m->size == 0))
		return;

	for (i = 0; i < g_alloc_count; i++) {
		if (m->cpu != NULL ? g_alloc[i].cpu == m->cpu : g_alloc[i].mc == m->mc) {
			free(g_alloc[i].cpu);
			g_alloc[i] = g_alloc[g_alloc_count - 1];
			g_alloc_count--;
			break;
		}
	}
	memset(m, 0, sizeof(*m));
}

/* --- the doorbell and the CP stub -------------------------------------------------------------- */

/* What a ring test's packet must be. gfx_v10_0_ring_test_ring() writes 0xCAFEDEAD to SCRATCH_REG0
 * and submits one PACKET3_SET_UCONFIG_REG that sets the same register to 0xDEADBEEF; nothing else in
 * this window submits a SET_UCONFIG_REG at all. */
#define RING_TEST_VALUE   0xDEADBEEFu

void backend_cp_stub_expect(u32 scratch_reg0_dword_index)
{
	g_scratch_reg0_dword = scratch_reg0_dword_index;
}

unsigned int backend_cp_stub_rejects(void) { return g_stub_rejects; }

/*
 * Execute one decoded packet, if it is the one the stub knows. Returns 1 if it did.
 *
 * This is a check, not an answer. Every condition below has to hold before anything is written, and
 * a packet that looks like a ring test but is malformed is counted as a rejection rather than
 * quietly ignored - so a shim that built the right packet at the wrong place, or the wrong packet at
 * the right place, fails loudly instead of merely timing out:
 *
 *   - the opcode is PACKET3_SET_UCONFIG_REG and the count says exactly one register;
 *   - the register it names, after adding PACKET3_SET_UCONFIG_REG_START, is SCRATCH_REG0, which the
 *     test resolves through AMD's headers and hands to backend_cp_stub_expect(), or
 *     CP_COHER_START_DELAY, which belongs to the dispatch sequence and is taken there instead;
 *   - the value is 0xDEADBEEF;
 *   - the packet was found inside the dwords the doorbell announced, which is what the decode loop
 *     in bc250_shim_wdoorbell64() guarantees by never looking past the write pointer.
 *
 * The last one is the point of doing this at the doorbell rather than by scanning the ring: a packet
 * written past the write pointer is a packet the CP would never have seen.
 */
/* ---------------------------------------------------------------------------------------------
 * The second half of the stub: a fence, and the interrupt it raises
 *
 * bc250_gfx_emit_fence() submits one RELEASE_MEM (gfx and compute rings) or two WRITE_DATA packets
 * (the KIQ). On hardware the CP writes the sequence number to memory and, if the packet asked for
 * it, raises an end-of-pipe interrupt, which arrives as a 32-byte vector in the IH ring. Both
 * halves are modelled here so that a host run can go all the way from "emit a fence" to
 * "bc250_ih_decode() returns a gfx EOP", which is the thing the first hardware run will check.
 *
 * The same discipline as above applies: this executes the packet it was given, it does not invent
 * one. The address has to resolve to an allocation this file handed out, the data-select has to be
 * one of the two the emitter can produce, and a packet that does not check out is a rejection.
 * A test that wants the interrupt half has to attach a ring with backend_ih_attach(); without one,
 * the fence value is still written and nothing is delivered.
 * ------------------------------------------------------------------------------------------- */

void backend_ih_attach(struct amdgpu_device *adev)
{
	g_ih_adev = adev;
	g_ih_wptr = 0;
	g_ih_delivered = 0;
}

void backend_ih_detach(void) { g_ih_adev = NULL; }
unsigned int backend_ih_delivered(void) { return g_ih_delivered; }
u32 backend_ih_wptr(void) { return g_ih_wptr; }

/* Put one interrupt vector in the ring and publish the write pointer, the way the IH block does:
 * eight dwords at the write pointer, then the write pointer into its write-back slot.
 *
 * The field packing is amdgpu_ih_decode_iv_helper()'s, read backwards. That is deliberate and it is
 * the point of doing it here rather than by handing bc250_ih_decode() a struct: the decode under
 * test and this encoder were written from the same upstream lines, so a field either side got wrong
 * shows up as a mismatch instead of cancelling out. */
static void deliver_iv(u32 client_id, u32 src_id, u32 ring_id, const u32 src_data[4])
{
	struct amdgpu_ih_ring *ih;
	volatile u32 *at;
	u32 index, k;

	if (g_ih_adev == NULL)
		return;
	ih = &g_ih_adev->irq.ih;
	if (ih->ring == NULL || ih->ring_size == 0)
		return;

	index = (g_ih_wptr & ih->ptr_mask) >> 2;
	at = (volatile u32 *)ih->ring + index;

	g_ih_timestamp++;
	at[0] = (client_id & 0xffu) | ((src_id & 0xffu) << 8) | ((ring_id & 0xffu) << 16);
	at[1] = (u32)(g_ih_timestamp & 0xffffffffu);
	at[2] = (u32)((g_ih_timestamp >> 32) & 0xffffu);
	at[3] = 0;
	for (k = 0; k < 4; k++)
		at[4 + k] = src_data != NULL ? src_data[k] : 0;

	g_ih_wptr = (g_ih_wptr + 32u) & ih->ptr_mask;
	if (ih->wptr_cpu != NULL)
		*ih->wptr_cpu = g_ih_wptr;
	g_ih_delivered++;
}

/* The ring_id the CP puts in a vector. gfx_v10_0.c:9195-9197 packs me, pipe and queue into it; this
 * is that expression solved for ring_id, from the ring the doorbell belonged to.
 *
 * Against unit A, evidence/linux/2026-09-21-E13-reference-2/boot3-readonly/amdgpu-events-ib.txt
 * lines 14-25: the gfx ring gives ring 0, the eight compute rings give 4, 5, 6, 7 and 20, 21, 22,
 * 23, and the KIQ - named kiq_0.2.1.0 in the ring dumps, so me 2, pipe 1, queue 0 - gives 9. This
 * expression reproduces all ten.
 *
 * It holds for a FENCE, which is the only vector this stub raises. It does not hold for the vectors
 * the CP raises when it completes an UNMAP_QUEUES: unit A sends those with the queue last active on
 * each pipe (facts M45, ring ids 20, 21, 22, 7 twice over for eight distinct queues) and with
 * src_data[0] = 1 where a fence carries 0x80000000. Nothing here models those, deliberately - a
 * stub that invented them from this expression would assert something hardware has already
 * contradicted. */
static u32 eop_ring_id(const struct amdgpu_ring *ring)
{
	return ((ring->me & 0x3u) << 2) | (ring->pipe & 0x3u) | ((ring->queue & 0x7u) << 4);
}

static void deliver_eop(const struct amdgpu_ring *ring)
{
	if (ring == NULL)
		return;
	deliver_iv(SOC15_IH_CLIENTID_GRBM_CP, GFX_10_1__SRCID__CP_EOP_INTERRUPT,
		   eop_ring_id(ring), NULL);
}

/* PACKET3_RELEASE_MEM, as gfx_v10_0_ring_emit_fence() builds it. Returns 1 if it was executed. */
static int stub_release_mem(const struct backend_packet *p, const struct amdgpu_ring *ring)
{
	u32 dw2, data_sel, int_sel;
	u64 addr, seq;
	void *dst;

	/* Seven body dwords: two control, the 64-bit address, the 64-bit data, and a trailing zero. */
	if (p->count != 6 || p->body_dwords < 7) {
		fprintf(stderr, "backend_mem: RELEASE_MEM count %u, body %u; expected 6 and 7\n",
			p->count, p->body_dwords);
		g_stub_rejects++;
		return 0;
	}

	/* The first body dword carries the cache operations and the event the CP raises. It is the
	 * same on every fence unit A's Linux driver emits, so it is checked whole rather than by
	 * field: a wrong event type or a missing GCR bit is a wrong fence even when the sequence
	 * number still lands. */
	if (p->body[0] != FENCE_RELEASE_MEM_CNTL) {
		fprintf(stderr, "backend_mem: RELEASE_MEM control dword %08X; amdgpu emits %08X on"
				" unit A (E13 rings-after-ib)\n",
			p->body[0], FENCE_RELEASE_MEM_CNTL);
		g_stub_rejects++;
		return 0;
	}

	dw2 = p->body[1];
	data_sel = (dw2 >> 29) & 0x7u;          /* PACKET3_RELEASE_MEM_DATA_SEL(x) is (x) << 29 */
	int_sel = (dw2 >> 24) & 0x7u;           /* PACKET3_RELEASE_MEM_INT_SEL(x)  is (x) << 24 */

	addr = (u64)p->body[2] | ((u64)p->body[3] << 32);
	seq = (u64)p->body[4] | ((u64)p->body[5] << 32);

	if (data_sel != 1u && data_sel != 2u) {
		fprintf(stderr, "backend_mem: RELEASE_MEM DATA_SEL %u; the emitter only makes 1 and 2\n",
			data_sel);
		g_stub_rejects++;
		return 0;
	}

	dst = mc_to_cpu(addr, data_sel == 2u ? 8u : 4u);
	if (dst == NULL) {
		fprintf(stderr, "backend_mem: RELEASE_MEM writes 0x%llX, which is in no allocation\n",
			(unsigned long long)addr);
		g_stub_rejects++;
		return 0;
	}

	if (data_sel == 2u)
		*(volatile u64 *)dst = seq;
	else
		*(volatile u32 *)dst = (u32)seq;

	/* INT_SEL 2 is "interrupt when the data write is confirmed", which is what the emitter puts
	 * there for AMDGPU_FENCE_FLAG_INT; 0 is no interrupt, and that is the control the test runs. */
	if (int_sel != 0)
		deliver_eop(ring);

	return 1;
}

/* PACKET3_WRITE_DATA, the two shapes gfx_v10_0_ring_emit_fence_kiq() builds: DST_SEL 5 writes the
 * sequence number to memory, DST_SEL 0 writes CPC_INT_STATUS, which is how the KIQ raises its
 * interrupt. Returns 1 if it was executed. */
static int stub_write_data(const struct backend_packet *p, const struct amdgpu_ring *ring)
{
	u32 cntl, dst_sel;
	u64 addr;

	if (p->count != 3 || p->body_dwords < 4) {
		fprintf(stderr, "backend_mem: WRITE_DATA count %u, body %u; expected 3 and 4\n",
			p->count, p->body_dwords);
		g_stub_rejects++;
		return 0;
	}

	cntl = p->body[0];
	dst_sel = (cntl >> 8) & 0xfu;           /* WRITE_DATA_DST_SEL(x) is (x) << 8 */
	addr = (u64)p->body[1] | ((u64)p->body[2] << 32);

	/* Both control dwords are pinned, not just DST_SEL: without WR_CONFIRM the CP would not wait
	 * for the write, and the fence would be signalled before its value was visible. */
	if (cntl != FENCE_WRITE_DATA_CNTL_MEM && cntl != FENCE_WRITE_DATA_CNTL_REG) {
		fprintf(stderr, "backend_mem: WRITE_DATA control dword %08X; amdgpu emits %08X to"
				" memory and %08X to a register on unit A (E13 rings-after-ib)\n",
			cntl, FENCE_WRITE_DATA_CNTL_MEM, FENCE_WRITE_DATA_CNTL_REG);
		g_stub_rejects++;
		return 0;
	}

	if (dst_sel == 5u) {                    /* memory */
		void *dst = mc_to_cpu(addr, 4u);

		if (dst == NULL) {
			fprintf(stderr, "backend_mem: WRITE_DATA writes 0x%llX, which is in no"
					" allocation\n", (unsigned long long)addr);
			g_stub_rejects++;
			return 0;
		}
		*(volatile u32 *)dst = p->body[3];
		return 1;
	}

	if (dst_sel == 0u) {                    /* a register; the KIQ's interrupt trigger */
		u32 reg_dword = p->body[1];     /* DST_SEL 0 puts a dword index where the address goes */
		const struct amdgpu_device *adev = ring != NULL ? ring->adev : NULL;

		if (adev == NULL) {
			fprintf(stderr, "backend_mem: WRITE_DATA to a register from a ring with no"
					" device; the register cannot be named\n");
			g_stub_rejects++;
			return 0;
		}

		/* There is exactly one register a fence may write, and naming it through AMD's header
		 * rather than by its number is what makes this a check and not a restatement. On unit
		 * A amdgpu writes dword 0x30b5 here (E13 amdgpu_ring_kiq_0.2.1.0.txt dw 0x0709 and
		 * 0x0E09), which is mmCPC_INT_STATUS over the GC base of this SoC. */
		if (reg_dword != SOC15_REG_OFFSET(GC, 0, mmCPC_INT_STATUS)) {
			fprintf(stderr, "backend_mem: a fence writes register dword 0x%X; the only one"
					" it may write is mmCPC_INT_STATUS, dword 0x%X\n",
				reg_dword, SOC15_REG_OFFSET(GC, 0, mmCPC_INT_STATUS));
			g_stub_rejects++;
			return 0;
		}

		backend_poke(reg_dword * 4u, p->body[3]);
		/* Unit A sends this vector with ring_id 9, the KIQ's me 2, pipe 1, queue 0: E13
		 * amdgpu-events-ib.txt:23, client_id 20 src_id 178 ring 9. It used to be sent as 0
		 * here, which nothing reads - neither gfx_v10_0_kiq_irq() (gfx_v10_0.c:9456) nor
		 * bc250_ih_is_kiq() looks at ring_id for the KIQ - but a test that delivers a vector
		 * hardware does not send is testing the wrong thing. */
		deliver_iv(SOC15_IH_CLIENTID_GRBM_CP, GFX_10_1__SRCID__CP_IB2_INTERRUPT_PKT,
			   eop_ring_id(ring), NULL);
		return 1;
	}

	fprintf(stderr, "backend_mem: WRITE_DATA DST_SEL %u; the emitter only makes 0 and 5\n", dst_sel);
	g_stub_rejects++;
	return 0;
}

/* ---------------------------------------------------------------------------------------------
 * The third stub: a compute dispatch
 *
 * bc250_gfx_dispatch_memset() sets up the COMPUTE_* state with SET_SH_REG packets and then launches
 * it with DISPATCH_DIRECT. There is no shader core here, so what this does is keep the state the
 * packets set, refuse anything it cannot account for, and on the launch perform the store the
 * shader would have performed - one 16-byte record per thread, out of the buffer descriptor in
 * COMPUTE_USER_DATA_0..3 and the pattern in COMPUTE_USER_DATA_4..7.
 *
 * It is not a simulator and is not meant to be. What it can say is: the packets name the registers
 * the reference names, the program address points at the shader the driver copied in, the
 * descriptor is a 16-byte-stride buffer inside an allocation this file handed out, and the number of
 * records the dispatch covers is what the workgroup count says. That is the whole of what a host run
 * can check about a dispatch, and all of it would otherwise be checked by eye.
 *
 * The out-of-bounds rule is modelled because it is a real difference: the descriptor's OOB_SELECT
 * bounds stores against NUM_RECORDS, so a dispatch that covers more records than the buffer holds
 * drops the excess rather than writing past it.
 * ------------------------------------------------------------------------------------------- */

struct cs_state {
	u32 pgm_lo, pgm_hi;
	u32 rsrc1, rsrc2, rsrc3;
	u32 thread_x, thread_y, thread_z;
	u32 user_data[8];
	u32 resource_limits;
	u32 tmpring_size;
	unsigned int cu_mask_packets;   /* the two SET_SH_REG_INDEX packets, if the caller emits them */
	unsigned int sh_writes;         /* how many registers have been set since the last dispatch */
	unsigned int coher_packets;     /* the one SET_UCONFIG_REG of the sequence */
	u32 coher_start_delay;
};

static struct cs_state g_cs;
static unsigned int g_dispatches;

unsigned int backend_dispatch_count(void) { return g_dispatches; }

static void cs_state_clear(void)
{
	memset(&g_cs, 0, sizeof(g_cs));
	g_dispatches = 0;
}

/* One register of the compute state. Returns 1 if the stub knows the register, 0 if it does not -
 * and not knowing it is a rejection, because a dispatch built out of registers this file cannot name
 * is a dispatch nobody has checked. */
static int cs_store(struct amdgpu_device *adev, u32 reg, u32 v)
{
	u32 base;

	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_PGM_LO))          { g_cs.pgm_lo = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_PGM_HI))          { g_cs.pgm_hi = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_PGM_RSRC1))       { g_cs.rsrc1 = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_PGM_RSRC2))       { g_cs.rsrc2 = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_PGM_RSRC3))       { g_cs.rsrc3 = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_NUM_THREAD_X))    { g_cs.thread_x = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_NUM_THREAD_Y))    { g_cs.thread_y = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_NUM_THREAD_Z))    { g_cs.thread_z = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_RESOURCE_LIMITS)) { g_cs.resource_limits = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_TMPRING_SIZE))    { g_cs.tmpring_size = v; return 1; }
	if (reg == SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_SHADER_CHKSUM))   { return 1; }

	base = SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_USER_DATA_0);
	if (reg >= base && reg < base + ARRAY_SIZE(g_cs.user_data)) {
		g_cs.user_data[reg - base] = v;
		return 1;
	}

	/* COMPUTE_START_X/Y/Z, three registers the reference clears (shader_test_util.c:218-220). */
	base = SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_START_X);
	if (reg >= base && reg < base + 3u)
		return v == 0;

	/* The four CU masks, which the MQD has already set to the same value. */
	base = SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_STATIC_THREAD_MGMT_SE0);
	if (reg == base || reg == base + 1u)
		return 1;
	base = SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_STATIC_THREAD_MGMT_SE2);
	if (reg == base || reg == base + 1u)
		return 1;

	/* The six dwords from COMPUTE_REQ_CTRL (shader_test_util.c:244-246). One of them, mm 0x1bc3,
	 * has no name in gc_10_1_0_offset.h at all; the reference writes zero to it on every gfx10
	 * part, so zero is accepted here and anything else is not. */
	base = SOC15_REG_OFFSET(GC, 0, mmCOMPUTE_REQ_CTRL);
	if (reg >= base && reg < base + 6u)
		return v == 0;

	return 0;
}

/* SET_SH_REG and SET_SH_REG_INDEX. `indexed` also carries an index in the top four bits of the
 * offset dword, which must be 3, the CU-mask path libdrm uses. */
static int stub_set_sh_reg(const struct backend_packet *p, const struct amdgpu_ring *ring,
			   int indexed)
{
	struct amdgpu_device *adev = ring->adev;
	u32 first, index, k;

	if (p->body_dwords < 2u || p->count + 1u != p->body_dwords) {
		fprintf(stderr, "backend_mem: SET_SH_REG count %u with %u body dwords\n",
			p->count, p->body_dwords);
		g_stub_rejects++;
		return 0;
	}

	index = p->body[0] >> 28;
	first = (p->body[0] & 0xffffu) + PACKET3_SET_SH_REG_START;

	if (indexed) {
		if (index != 3u) {
			fprintf(stderr, "backend_mem: SET_SH_REG_INDEX index %u; the reference uses 3\n",
				index);
			g_stub_rejects++;
			return 0;
		}
		g_cs.cu_mask_packets++;
	} else if (index != 0u) {
		fprintf(stderr, "backend_mem: SET_SH_REG with index %u set\n", index);
		g_stub_rejects++;
		return 0;
	}

	for (k = 1u; k < p->body_dwords; k++) {
		if (!cs_store(adev, first + k - 1u, p->body[k])) {
			fprintf(stderr, "backend_mem: SET_SH_REG names register dword 0x%X = %08X,"
					" which is not part of the dispatch this stub knows\n",
				first + k - 1u, p->body[k]);
			g_stub_rejects++;
			return 0;
		}
		g_cs.sh_writes++;
	}
	return 1;
}

/* DISPATCH_DIRECT: check the state the packets built, then do what the shader would do. */
static int stub_dispatch_direct(const struct backend_packet *p, const struct amdgpu_ring *ring)
{
	u64 pgm, dst;
	u32 dim_x, dim_y, dim_z, initiator, stride, num_records, records, i;
	const u32 *shader;
	void *dst_cpu;

	(void)ring;     /* the state came from the SET_SH_REG packets, not from the ring */

	if (p->body_dwords < 4u || p->count != 3u) {
		g_stub_rejects++;
		return 0;
	}
	dim_x = p->body[0];
	dim_y = p->body[1];
	dim_z = p->body[2];
	initiator = p->body[3];

	if (dim_y != 1u || dim_z != 1u || g_cs.thread_y != 1u || g_cs.thread_z != 1u) {
		fprintf(stderr, "backend_mem: dispatch is %ux%ux%u of %ux%ux%u; this stub knows the"
				" one-dimensional memset only\n", dim_x, dim_y, dim_z,
			g_cs.thread_x, g_cs.thread_y, g_cs.thread_z);
		g_stub_rejects++;
		return 0;
	}
	if ((initiator & 1u) == 0u) {            /* COMPUTE_DISPATCH_INITIATOR.COMPUTE_SHADER_EN */
		fprintf(stderr, "backend_mem: DISPATCH_DIRECT with COMPUTE_SHADER_EN clear (%08X)\n",
			initiator);
		g_stub_rejects++;
		return 0;
	}
	/* The rest of the sequence has to have been emitted in front of this packet. Neither register
	 * is read back by anything here, so without this the stub would execute a dispatch that had
	 * skipped them - and on hardware the CU masks left by the MQD and a stale CP_COHER_START_DELAY
	 * are exactly the kind of difference that shows up as a hang rather than as wrong data. */
	if (g_cs.cu_mask_packets != 2u || g_cs.coher_packets != 1u) {
		fprintf(stderr, "backend_mem: the dispatch was preceded by %u CU-mask packets and %u"
				" uconfig packets, not 2 and 1\n",
			g_cs.cu_mask_packets, g_cs.coher_packets);
		g_stub_rejects++;
		return 0;
	}
	if (g_cs.tmpring_size != 0u) {
		fprintf(stderr, "backend_mem: COMPUTE_TMPRING_SIZE is %08X; a scratch ring needs"
				" COMPUTE_DISPATCH_SCRATCH_BASE, which nothing here programs\n",
			g_cs.tmpring_size);
		g_stub_rejects++;
		return 0;
	}

	/* The program address, and the shader that has to be at it. This is what says the driver
	 * copied the right words to the right place and shifted the address the right way. */
	pgm = ((u64)g_cs.pgm_lo << 8) | ((u64)g_cs.pgm_hi << 40);
	shader = (const u32 *)mc_to_cpu(pgm, (u32)sizeof(bufferclear_cs_shader_gfx10));
	if (shader == NULL) {
		fprintf(stderr, "backend_mem: COMPUTE_PGM points at 0x%llX, which is in no allocation\n",
			(unsigned long long)pgm);
		g_stub_rejects++;
		return 0;
	}
	if (memcmp(shader, bufferclear_cs_shader_gfx10,
		   sizeof(bufferclear_cs_shader_gfx10)) != 0) {
		fprintf(stderr, "backend_mem: the words at 0x%llX are not bufferclear_cs_shader_gfx10\n",
			(unsigned long long)pgm);
		g_stub_rejects++;
		return 0;
	}

	/* The buffer resource in USER_DATA_0..3. Word 1 carries the top 16 bits of the address in its
	 * low half and the stride above it; word 2 is NUM_RECORDS. */
	dst = (u64)g_cs.user_data[0] | ((u64)(g_cs.user_data[1] & 0xffffu) << 32);
	stride = (g_cs.user_data[1] >> 16) & 0x3fffu;
	num_records = g_cs.user_data[2];

	if (stride != 16u) {
		fprintf(stderr, "backend_mem: buffer stride is %u bytes; the shader stores 16\n", stride);
		g_stub_rejects++;
		return 0;
	}
	if (num_records == 0u) {
		g_stub_rejects++;
		return 0;
	}

	records = dim_x * g_cs.thread_x;
	if (records > num_records)
		records = num_records;          /* OOB_SELECT bounds the stores, it does not wrap */

	dst_cpu = mc_to_cpu(dst, records * 16u);
	if (dst_cpu == NULL) {
		fprintf(stderr, "backend_mem: the dispatch writes %u records at 0x%llX, which is not"
				" inside one allocation\n", records, (unsigned long long)dst);
		g_stub_rejects++;
		return 0;
	}

	for (i = 0; i < records; i++) {
		volatile u32 *rec = (volatile u32 *)dst_cpu + i * 4u;

		rec[0] = g_cs.user_data[4];
		rec[1] = g_cs.user_data[5];
		rec[2] = g_cs.user_data[6];
		rec[3] = g_cs.user_data[7];
	}

	g_dispatches++;
	g_cs.sh_writes = 0;
	g_cs.cu_mask_packets = 0;
	g_cs.coher_packets = 0;
	return 1;
}

/* MAP_QUEUES and UNMAP_QUEUES name their queue by its doorbell (bc250_gfx.c:1265 and :1290, the
 * second body dword, shifted by two in both packets: PACKET3_MAP_QUEUES_DOORBELL_OFFSET(x) and
 * PACKET3_UNMAP_QUEUES_DOORBELL_OFFSET0(x) are both `(x) << 2`, nvd.h:616 and :638). */
static int stub_map_unmap(const struct backend_packet *p, int mapped)
{
	unsigned int i, index;

	if (p->body_dwords < 2)
		return 0;
	index = (p->body[1] >> 2) & 0x3FFFFFFu;
	for (i = 0; i < g_ring_count; i++) {
		if (g_ring[i].ring->doorbell_index != index ||
		    g_ring[i].ring->funcs->type != AMDGPU_RING_TYPE_COMPUTE)
			continue;
		/* The queue the test has pinned does not let go. See backend_hqd_pin(). */
		if (!mapped && g_ring[i].hqd_pinned)
			continue;
		g_ring[i].hqd_mapped = mapped;
		g_ring[i].hqd_mapped_known = 1;
	}
	return 0;                       /* recorded, not counted as a stub hit: the counts are compared */
}

void backend_hqd_pin(const struct amdgpu_ring *ring, int pinned)
{
	unsigned int i;

	for (i = 0; i < g_ring_count; i++)
		if (g_ring[i].ring == ring)
			g_ring[i].hqd_pinned = pinned;
}

/* ---------------------------------------------------------------------------------------------
 * The fourth stub: an indirect buffer
 *
 * PACKET3_INDIRECT_BUFFER points the CP at dwords somewhere else and it executes them as if they
 * had been in the ring. The stub does the same, for the one address space it can: VMID 0, the flat
 * GART aperture, where an MC address is an allocation this file handed out. Anything else is
 * counted as skipped and left alone - see backend_mem.h for why that is not the same as ignoring it.
 *
 * Same discipline as everywhere above. The packet's own count has to be right, the length has to
 * fit inside the buffer the address resolves to, the packets inside go through stub_execute() like
 * any others, and an IB that names another IB is a rejection: the CP does allow chaining, nothing
 * in this driver emits it, and a stub that followed one would be modelling something no test has
 * ever looked at.
 * ------------------------------------------------------------------------------------------- */

unsigned int backend_ib_followed(void) { return g_ib_followed; }
unsigned int backend_ib_skipped(void)  { return g_ib_skipped; }

static int stub_execute(const struct backend_packet *p, const struct amdgpu_ring *ring);

static int stub_indirect_buffer(const struct backend_packet *p, const struct amdgpu_ring *ring)
{
	const u32 *ib;
	u64 addr;
	u32 length_dw, vmid, at;
	unsigned int ran = 0;

	/* PACKET3(PACKET3_INDIRECT_BUFFER, 2): the header plus three body dwords. */
	if (p->count != 2 || p->body_dwords < 3) {
		fprintf(stderr, "backend_mem: INDIRECT_BUFFER count %u, body %u; expected 2 and 3\n",
			p->count, p->body_dwords);
		g_stub_rejects++;
		return 0;
	}
	if (g_ib_depth != 0) {
		fprintf(stderr, "backend_mem: an INDIRECT_BUFFER inside an indirect buffer; nothing in"
				" this driver chains them\n");
		g_stub_rejects++;
		return 0;
	}

	addr = (u64)p->body[0] | ((u64)p->body[1] << 32);
	/* nvd.h gives setters and no getters, so each field is taken apart with its own macro where
	 * that works and with the macro's shift restated where it does not, exactly as the
	 * RELEASE_MEM decode above does. IB_SIZE shifts by nothing, so the macro of all-ones is its
	 * mask; VMID's shift is the 24 in PACKET3_INDIRECT_BUFFER__VMID(x) (nvd.h:239). */
	length_dw = p->body[2] & PACKET3_INDIRECT_BUFFER__IB_SIZE(~0u);
	vmid = (p->body[2] & PACKET3_INDIRECT_BUFFER__VMID(~0u)) >> 24;

	if (vmid != 0) {
		g_ib_skipped++;
		return 0;
	}
	if (length_dw == 0) {
		fprintf(stderr, "backend_mem: INDIRECT_BUFFER of 0 dwords\n");
		g_stub_rejects++;
		return 0;
	}

	ib = (const u32 *)mc_to_cpu(addr, length_dw * 4u);
	if (ib == NULL) {
		fprintf(stderr, "backend_mem: INDIRECT_BUFFER at 0x%llX covering %u dwords is in no"
				" allocation\n", (unsigned long long)addr, length_dw);
		g_stub_rejects++;
		return 0;
	}

	g_ib_depth = 1;
	for (at = 0; at < length_dw; ) {
		u32 header = ib[at];
		struct backend_packet decoded;
		unsigned int count, body, k;

		if (header == ring->funcs->nop) {       /* the same one-dword filler the ring decode knows */
			at++;
			continue;
		}
		if (CP_PACKET_GET_TYPE(header) != PACKET_TYPE3) {
			at++;
			continue;
		}

		count = CP_PACKET_GET_COUNT(header);
		body = count + 1u;
		if (at + 1u + body > length_dw) {
			fprintf(stderr, "backend_mem: a packet at dword %u of the indirect buffer runs"
					" past its %u dwords\n", at, length_dw);
			g_stub_rejects++;
			break;
		}

		memset(&decoded, 0, sizeof(decoded));
		decoded.doorbell_index = p->doorbell_index;
		decoded.opcode = CP_PACKET3_GET_OPCODE(header);
		decoded.count = count;
		decoded.first_dword = at;
		decoded.body_dwords = body < 8u ? body : 8u;
		for (k = 0; k < decoded.body_dwords; k++)
			decoded.body[k] = ib[at + 1u + k];

		if (g_packet_count < MAX_PACKETS)
			g_packet[g_packet_count++] = decoded;

		ran += (unsigned int)stub_execute(&decoded, ring);
		at += 1u + body;
	}
	g_ib_depth = 0;

	g_ib_followed++;
	g_stub_hits += ran;             /* what the packets inside did; the fetch itself is the 1 below */
	return 1;
}

static int stub_execute(const struct backend_packet *p, const struct amdgpu_ring *ring)
{
	struct amdgpu_device *adev = ring->adev;   /* SOC15_REG_OFFSET() reads it by that name */
	u32 reg_dword, value;

	if (p->opcode == PACKET3_RELEASE_MEM)
		return stub_release_mem(p, ring);
	if (p->opcode == PACKET3_WRITE_DATA)
		return stub_write_data(p, ring);
	if (p->opcode == PACKET3_SET_SH_REG)
		return stub_set_sh_reg(p, ring, 0);
	if (p->opcode == PACKET3_SET_SH_REG_INDEX)
		return stub_set_sh_reg(p, ring, 1);
	if (p->opcode == PACKET3_DISPATCH_DIRECT)
		return stub_dispatch_direct(p, ring);
	if (p->opcode == PACKET3_MAP_QUEUES)
		return stub_map_unmap(p, 1);
	if (p->opcode == PACKET3_UNMAP_QUEUES)
		return stub_map_unmap(p, 0);
	if (p->opcode == PACKET3_INDIRECT_BUFFER)
		return stub_indirect_buffer(p, ring);

	if (p->opcode != PACKET3_SET_UCONFIG_REG)
		return 0;                       /* not a ring test; SET_RESOURCES and the rest */

	if (p->count != 1 || p->body_dwords < 2) {
		g_stub_rejects++;
		return 0;
	}

	reg_dword = p->body[0] + PACKET3_SET_UCONFIG_REG_START;
	value = p->body[1];

	/* The one uconfig register of the dispatch sequence (shader_test_util.c:248-250). It is in
	 * the same packet space as SCRATCH_REG0 and would otherwise be read as a malformed ring
	 * test, so it is recognised here first, resolved through AMD's headers like every other
	 * register this file names. Recorded rather than poked into the register file: nothing reads
	 * it back, and a poke would seed the sweep layer with a GC register the traced bring-up
	 * never writes. */
	if (reg_dword == SOC15_REG_OFFSET(GC, 0, mmCP_COHER_START_DELAY)) {
		g_cs.coher_start_delay = value;
		g_cs.coher_packets++;
		return 1;
	}

	if (g_scratch_reg0_dword != 0 && reg_dword != g_scratch_reg0_dword) {
		fprintf(stderr, "backend_mem: SET_UCONFIG_REG names dword 0x%X, not SCRATCH_REG0 0x%X\n",
			reg_dword, g_scratch_reg0_dword);
		g_stub_rejects++;
		return 0;
	}
	if (value != RING_TEST_VALUE) {
		fprintf(stderr, "backend_mem: ring test writes %08X, not %08X\n",
			value, RING_TEST_VALUE);
		g_stub_rejects++;
		return 0;
	}

	backend_poke(reg_dword * 4u, value);
	return 1;
}

/* ---------------------------------------------------------------------------------------------
 * The second stub: the SDMA engine
 *
 * An SDMA packet carries no length in its header, so unlike the CP decoder above this one has to
 * know how long each opcode is. It knows the four bc250_sdma.c emits and refuses anything else,
 * which is the point: a packet the stub cannot name is a packet the test must not pass silently.
 *
 * The sizes are the packet layouts in navi10_sdma_pkt_open.h, and every one of them is confirmed by
 * what unit A's Linux driver left in its rings:
 * evidence/linux/2026-09-21-E13-reference-2/boot3-readonly/rings-after-ib/amdgpu_ring_sdma1.txt
 * dw 0x0000 is a five-dword WRITE_LINEAR of one dword, dw 0x0005 an eleven-dword NOP, dw 0x0020 a
 * four-dword FENCE and dw 0x0024 a two-dword TRAP.
 * ------------------------------------------------------------------------------------------- */

static u32 sdma_dw(const struct amdgpu_ring *ring, u64 at, unsigned int k)
{
	return ring->ring[(size_t)((at + k) & ring->buf_mask)];
}

/* sdma_v5_0.c:1387-1399 registers one source id under two client ids, one per engine, and
 * sdma_v5_0_process_trap_irq() picks the instance from entry->client_id. ring->me is the engine.
 * Unit A: E13 amdgpu-events-ib.txt:24 and :25, client_id 8 and 9, both src_id 224, both ring 0. */
static void deliver_sdma_trap(const struct amdgpu_ring *ring)
{
	if (ring->me == 0)
		deliver_iv(SOC15_IH_CLIENTID_SDMA0, SDMA0_5_0__SRCID__SDMA_TRAP, 0, NULL);
	else
		deliver_iv(SOC15_IH_CLIENTID_SDMA1, SDMA1_5_0__SRCID__SDMA_TRAP, 0, NULL);
}

/* Decodes the packet at `at`, executes it, and reports its length in dwords. Returns 0 and leaves
 * *size alone if the opcode is not one of the four. */
static int stub_sdma_execute(const struct amdgpu_ring *ring, u64 at, unsigned int *size)
{
	u32 header = sdma_dw(ring, at, 0);
	u32 op = header & SDMA_PKT_HEADER_op_mask;
	u32 sub_op = (header >> SDMA_PKT_HEADER_sub_op_shift) & SDMA_PKT_HEADER_sub_op_mask;
	u64 addr;
	void *dst;
	u32 count, k;

	if (op == SDMA_OP_NOP) {
		/* One header plus COUNT more dwords, the burst form amdgpu uses when the firmware
		 * supports it; COUNT 0 is the plain one-dword filler. */
		*size = 1u + ((header >> SDMA_PKT_NOP_HEADER_count_shift) &
			      SDMA_PKT_NOP_HEADER_count_mask);
		return 1;
	}

	if (op == SDMA_OP_WRITE && sub_op == SDMA_SUBOP_WRITE_LINEAR) {
		addr = (u64)sdma_dw(ring, at, 1) | ((u64)sdma_dw(ring, at, 2) << 32);
		count = sdma_dw(ring, at, 3) & SDMA_PKT_WRITE_UNTILED_DW_3_count_mask;
		*size = 5u + count;     /* header, address, count, then count + 1 data dwords */

		dst = mc_to_cpu(addr, (count + 1u) * 4u);
		if (dst == NULL) {
			fprintf(stderr, "backend_mem: SDMA WRITE_LINEAR writes 0x%llX, which is in no"
					" allocation\n", (unsigned long long)addr);
			g_stub_rejects++;
			return 0;
		}
		for (k = 0; k <= count; k++)
			((volatile u32 *)dst)[k] = sdma_dw(ring, at, 4u + k);
		return 1;
	}

	if (op == SDMA_OP_FENCE) {
		/* MTYPE 3, Ucached, is the only value sdma_v5_0_ring_emit_fence() writes, and the one
		 * in every fence of both of unit A's rings. */
		u32 mtype = (header >> SDMA_PKT_FENCE_HEADER_mtype_shift) &
			    SDMA_PKT_FENCE_HEADER_mtype_mask;

		*size = 4u;
		if (mtype != 3u) {
			fprintf(stderr, "backend_mem: SDMA FENCE MTYPE %u; amdgpu emits 3 (Ucached)\n",
				mtype);
			g_stub_rejects++;
			return 0;
		}
		addr = (u64)sdma_dw(ring, at, 1) | ((u64)sdma_dw(ring, at, 2) << 32);
		dst = mc_to_cpu(addr, 4u);
		if (dst == NULL) {
			fprintf(stderr, "backend_mem: SDMA FENCE writes 0x%llX, which is in no"
					" allocation\n", (unsigned long long)addr);
			g_stub_rejects++;
			return 0;
		}
		*(volatile u32 *)dst = sdma_dw(ring, at, 3);
		return 1;
	}

	if (op == SDMA_OP_TRAP) {
		*size = 2u;
		deliver_sdma_trap(ring);
		return 1;
	}

	fprintf(stderr, "backend_mem: SDMA opcode %u sub-op %u at dword %llu; the stub knows NOP,"
			" WRITE_LINEAR, FENCE and TRAP\n",
		op, sub_op, (unsigned long long)at);
	g_stub_rejects++;
	return 0;
}

/* ---------------------------------------------------------------------------------------------
 * The MEC's own fetch state. What this models and what was measured is in backend_mem.h.
 * ------------------------------------------------------------------------------------------- */

#define MAX_HQD_SLOTS 16u

struct hqd_slot {
	u32 selection;                  /* the GRBM_GFX_CNTL value that names this slot */
	int used;
	/* What the registers of this slot currently say. */
	u32 reg_base_lo, reg_base_hi, reg_rptr;
	/* What the ENGINE remembers, which is a different thing and the whole point. */
	int engine_live;
	u64 engine_base;                /* bytes */
	u64 engine_rptr;                /* dwords */
};

static struct backend_mec_regs g_mec;
static int g_mec_on;
static u32 g_mec_selection;
static int g_mec_halted = 1;            /* CP_MEC_CNTL comes out of reset with the halt bits set */
static struct hqd_slot g_hqd[MAX_HQD_SLOTS];
static unsigned int g_hqd_count;
static unsigned int g_mec_fault_count;
static u64 g_mec_fault_address;

/* Does GRBM_GFX_CNTL's current value name this ring's queue? The three fields are decoded through
 * AMD's own masks; nothing here encodes a selection, so this cannot agree with nv_grbm_select() by
 * repeating its arithmetic. */
static int selection_names(u32 selection, const struct amdgpu_ring *ring)
{
	return ((selection & GRBM_GFX_CNTL__MEID_MASK) >> GRBM_GFX_CNTL__MEID__SHIFT) == ring->me &&
	       ((selection & GRBM_GFX_CNTL__PIPEID_MASK) >> GRBM_GFX_CNTL__PIPEID__SHIFT) == ring->pipe &&
	       ((selection & GRBM_GFX_CNTL__QUEUEID_MASK) >> GRBM_GFX_CNTL__QUEUEID__SHIFT) == ring->queue;
}

static struct ring_slot *ring_selected(void)
{
	unsigned int i;

	for (i = 0; i < g_ring_count; i++) {
		/* Compute queues and the KIQ only. The HQD registers belong to them, and without
		 * this the gfx ring - me 0, pipe 0, queue 0 - would answer for GRBM_GFX_CNTL = 0,
		 * which is not a selection at all but the value nv_grbm_select() writes to give the
		 * selection back. */
		if (g_ring[i].ring->funcs->type != AMDGPU_RING_TYPE_COMPUTE &&
		    g_ring[i].ring->funcs->type != AMDGPU_RING_TYPE_KIQ)
			continue;
		if (selection_names(g_mec_selection, g_ring[i].ring))
			return &g_ring[i];
	}
	return NULL;
}

/*
 * CP_HQD_PQ_RPTR is one register per queue, and the replayed register file has one value per
 * offset. Without this, the eight compute queues and the KIQ would share a read pointer, the KIQ
 * dequeue's zeroing at the end of the teardown would appear to have zeroed all nine, and the arm
 * that checks the other eight could not fail. So the model answers from the queue the selection
 * names - and only once a ring test has actually run on it, so that a cold boot still reads unit
 * A's own seeded value and the 354-write comparison is untouched.
 */
static int backend_mec_answer(u32 byte_offset, u32 *value)
{
	struct ring_slot *slot;

	if (g_mec_on && byte_offset == g_mec.hqd_active) {
		slot = ring_selected();
		if (slot == NULL || !slot->hqd_mapped_known)
			return 0;
		*value = (u32)slot->hqd_mapped;
		return 1;
	}

	if (!g_mec_on || byte_offset != g_mec.hqd_pq_rptr)
		return 0;

	slot = ring_selected();
	if (slot == NULL || !slot->hqd_known)
		return 0;

	*value = slot->hqd_rptr;
	return 1;
}

int backend_add_mec_fetch_state(const struct backend_mec_regs *regs)
{
	if (g_mec_on || regs == NULL)
		return -1;
	g_mec = *regs;
	g_mec_on = 1;
	hooks_refresh();
	g_mec_selection = 0;
	g_mec_halted = 1;
	g_hqd_count = 0;
	memset(g_hqd, 0, sizeof(g_hqd));
	g_mec_fault_count = 0;
	g_mec_fault_address = 0;
	return 0;
}

unsigned int backend_mec_faults(void)   { return g_mec_fault_count; }
u64 backend_mec_fault_address(void)     { return g_mec_fault_address; }

static void mec_model_off(void)
{
	g_mec_on = 0;
	hooks_refresh();
	g_mec_selection = 0;
	g_mec_halted = 1;
	g_hqd_count = 0;
	g_mec_fault_count = 0;
	g_mec_fault_address = 0;
}

static struct hqd_slot *hqd_current(void)
{
	unsigned int i;

	for (i = 0; i < g_hqd_count; i++)
		if (g_hqd[i].selection == g_mec_selection)
			return &g_hqd[i];
	if (g_hqd_count >= MAX_HQD_SLOTS) {
		fprintf(stderr, "backend_mem: more than %u HQD slots selected, raise MAX_HQD_SLOTS\n",
			MAX_HQD_SLOTS);
		exit(2);
	}
	g_hqd[g_hqd_count].selection = g_mec_selection;
	g_hqd[g_hqd_count].used = 1;
	return &g_hqd[g_hqd_count++];
}

/* The engine starts fetching. Either it finds memory and picks up where its copy left off, or it
 * does not and UTCL2 raises the fault unit A raised. */
static void mec_resume_slot(struct hqd_slot *s)
{
	unsigned int i;
	u64 at = s->engine_base + s->engine_rptr * 4u;

	if (mc_to_cpu(at, 4u) == NULL) {
		u32 src_data[4];

		g_mec_fault_count++;
		g_mec_fault_address = at;
		s->engine_live = 0;

		/* Any ring that was about to be used on this slot now executes nothing, which is how
		 * the failure showed itself: the KIQ ring test timed out. */
		{
			u64 programmed = ((u64)s->reg_base_lo << 8) | ((u64)s->reg_base_hi << 40);

			for (i = 0; i < g_ring_count; i++)
				if (g_ring[i].ring->gpu_addr == programmed)
					g_ring[i].dead = 1;
		}

		memset(src_data, 0, sizeof(src_data));
		src_data[0] = (u32)(at >> 12);
		deliver_iv(g_mec.fault_client_id, g_mec.fault_src_id, 0, src_data);
		return;
	}

	/* The address is mapped, so the engine walks forward from where it stopped. This is the
	 * arm E12 run 001 took, where the second ring happened to land on the first one's address
	 * and the stale fetch found valid NOPs: no fault, just a long walk. */
	for (i = 0; i < g_ring_count; i++)
		if (g_ring[i].ring->gpu_addr == s->engine_base)
			g_ring[i].decoded_to = s->engine_rptr;
}

/* The engine advances its own read pointer as it consumes the ring. Nothing in a replayed register
 * file would do that, and without it the stale fetch of the next bring-up would start at the ring's
 * first dword - which is exactly the case that does NOT fault. So the stub's own progress is the
 * model's read pointer, which is what the read pointer means. */
static void mec_note_consumed(const struct amdgpu_ring *ring, u64 to)
{
	unsigned int i;

	if (!g_mec_on)
		return;
	for (i = 0; i < g_hqd_count; i++)
		if (g_hqd[i].engine_live && g_hqd[i].engine_base == ring->gpu_addr)
			g_hqd[i].engine_rptr = to;
}

void backend_mec_observe(u32 byte_offset, u32 value)
{
	struct hqd_slot *s;
	unsigned int i;

	if (!g_mec_on)
		return;

	if (byte_offset == g_mec.grbm_gfx_cntl) {
		g_mec_selection = value;
		return;
	}

	if (byte_offset == g_mec.mec_cntl) {
		int halted = (value & g_mec.mec_halt_mask) != 0;

		if (g_mec_halted && !halted) {
			/* Un-halt. Every slot either has an engine copy to resume from, or takes
			 * what its registers say - which is what a cold boot does. */
			for (i = 0; i < g_hqd_count; i++) {
				s = &g_hqd[i];
				if (!s->used)
					continue;
				if (!s->engine_live) {
					s->engine_base = ((u64)s->reg_base_lo << 8) |
							 ((u64)s->reg_base_hi << 40);
					s->engine_rptr = s->reg_rptr;
					if (s->engine_base != 0)
						s->engine_live = 1;
					continue;
				}
				mec_resume_slot(s);
			}
		}
		g_mec_halted = halted;
		return;
	}

	if (byte_offset == g_mec.hqd_pq_base) {
		hqd_current()->reg_base_lo = value;
		return;
	}
	if (byte_offset == g_mec.hqd_pq_base_hi) {
		hqd_current()->reg_base_hi = value;
		return;
	}
	if (byte_offset == g_mec.hqd_pq_rptr) {
		struct ring_slot *slot = ring_selected();

		hqd_current()->reg_rptr = value;
		/* The per-queue value the read above answers with. A driver that puts the register
		 * back is exactly what this is here to notice. */
		if (slot != NULL) {
			slot->hqd_rptr = value;
			slot->hqd_known = 1;
		}
		return;
	}

	if (byte_offset == g_mec.hqd_dequeue_request) {
		struct ring_slot *slot;

		if (value == 0 || g_mec_halted)
			return;                 /* a halted engine services nothing */
		s = hqd_current();
		s->engine_live = 0;             /* the engine lets the queue go */
		backend_poke(g_mec.hqd_active, 0);

		/* And in the per-queue copy, for a queue that has one. Only the KIQ is dequeued this
		 * way today, and the KIQ's active bit lives in the register file the poke above
		 * reaches - but a compute queue dequeued by hand would otherwise go on reading
		 * active, because the read hook prefers the per-queue value. */
		slot = ring_selected();
		if (slot != NULL && slot->hqd_mapped_known)
			slot->hqd_mapped = 0;
		return;
	}

	if (byte_offset == g_mec.hqd_active) {
		s = hqd_current();
		if (g_mec_halted)
			return;                 /* point 2: the write does not reach the engine */
		if (value & 1u) {
			s->engine_base = ((u64)s->reg_base_lo << 8) | ((u64)s->reg_base_hi << 40);
			s->engine_rptr = s->reg_rptr;
			s->engine_live = 1;
		} else {
			s->engine_live = 0;
		}
	}
}

/* ---------------------------------------------------------------------------------------------
 * The SDMA engines' own write pointer. What this models and what was measured is in backend_mem.h.
 * ------------------------------------------------------------------------------------------- */

#define MAX_SDMA_REG_SETS 2u

struct sdma_reg_set {
	const struct amdgpu_ring *ring;
	struct backend_sdma_regs regs;
};

static struct sdma_reg_set g_sdma_regs[MAX_SDMA_REG_SETS];
static unsigned int g_sdma_reg_count;
static unsigned int g_sdma_ignored;

static struct ring_slot *ring_slot_of(const struct amdgpu_ring *ring)
{
	unsigned int i;

	for (i = 0; i < g_ring_count; i++)
		if (g_ring[i].ring == ring)
			return &g_ring[i];
	return NULL;
}

int backend_add_sdma_pointer_state(struct amdgpu_ring *ring, const struct backend_sdma_regs *regs)
{
	unsigned int i;

	if (ring == NULL || regs == NULL)
		return -1;

	/* Idempotent by ring, for the same reason backend_ring_register() is: the teardown and the
	 * next setup hand back the same ring object, and the offsets are the same offsets. */
	for (i = 0; i < g_sdma_reg_count; i++) {
		if (g_sdma_regs[i].ring == ring) {
			g_sdma_regs[i].regs = *regs;
			hooks_refresh();
			return 0;
		}
	}
	if (g_sdma_reg_count >= MAX_SDMA_REG_SETS)
		return -1;
	g_sdma_regs[g_sdma_reg_count].ring = ring;
	g_sdma_regs[g_sdma_reg_count].regs = *regs;
	g_sdma_reg_count++;
	hooks_refresh();
	return 0;
}

u64 backend_sdma_engine_wptr(const struct amdgpu_ring *ring)
{
	const struct ring_slot *slot = ring_slot_of(ring);

	return slot != NULL ? slot->sdma_engine_ptr : 0;
}

int backend_sdma_engine_ran(const struct amdgpu_ring *ring)
{
	const struct ring_slot *slot = ring_slot_of(ring);

	return slot != NULL ? slot->sdma_ran : 0;
}

void backend_sdma_hold_back(const struct amdgpu_ring *ring, u64 bytes)
{
	struct ring_slot *slot = ring_slot_of(ring);

	if (slot != NULL)
		slot->sdma_held_back = bytes;
}

void backend_sdma_force_engine_wptr(const struct amdgpu_ring *ring, u64 bytes)
{
	struct ring_slot *slot = ring_slot_of(ring);

	if (slot == NULL)
		return;
	slot->sdma_engine_ptr = bytes;
	slot->sdma_ran = 1;
	slot->decoded_to = bytes >> 2;
}

unsigned int backend_sdma_ignored_doorbells(void) { return g_sdma_ignored; }

/* A new boot. The engines lose their pointers here and nowhere else - not at a teardown, not at a
 * ring registration, which is the whole of point 2 in the header. */
static void sdma_model_off(void)
{
	unsigned int i;

	for (i = 0; i < MAX_RINGS; i++) {
		g_ring[i].sdma_engine_ptr = 0;
		g_ring[i].sdma_ran = 0;
		g_ring[i].sdma_held_back = 0;
	}
	g_sdma_reg_count = 0;
	g_sdma_ignored = 0;
	hooks_refresh();
}

/*
 * Answer a read of an engine's pointer registers with the pointer the engine holds, once it has run.
 *
 * Before it has run the register file answers, so a cold boot reads unit A's own swept value and
 * the first bring-up is exactly what it was. Writes are not handled at all, and that is the model:
 * point 3 says they do not reach the engine, so the write lands in the register file where nobody
 * asks for it again.
 */
static int sdma_answer(u32 byte_offset, u32 *value)
{
	unsigned int i;

	/* An offset a caller left out of the table reads 0, and no SDMA register is at BAR5+0. */
	if (byte_offset == 0)
		return 0;

	for (i = 0; i < g_sdma_reg_count; i++) {
		const struct backend_sdma_regs *r = &g_sdma_regs[i].regs;
		const struct ring_slot *slot = ring_slot_of(g_sdma_regs[i].ring);
		u64 read_ptr;

		if (slot == NULL || !slot->sdma_ran)
			continue;

		/* How far the engine has got, which is the write pointer unless a test has asked for
		 * an engine that stopped part-way (backend_sdma_hold_back()). */
		read_ptr = slot->sdma_held_back <= slot->sdma_engine_ptr
			   ? slot->sdma_engine_ptr - slot->sdma_held_back : 0;

		if (byte_offset == r->rb_wptr) {
			*value = lower_32_bits(slot->sdma_engine_ptr);
			return 1;
		}
		if (byte_offset == r->rb_wptr_hi) {
			*value = upper_32_bits(slot->sdma_engine_ptr);
			return 1;
		}
		if (byte_offset == r->rb_rptr || byte_offset == r->rb_rptr_fetch) {
			*value = lower_32_bits(read_ptr);
			return 1;
		}
		if (byte_offset == r->rb_rptr_hi || byte_offset == r->rb_rptr_fetch_hi) {
			*value = upper_32_bits(read_ptr);
			return 1;
		}
	}
	return 0;
}

/* ---------------------------------------------------------------------------------------------
 * The two hooks backend_trace.c keeps, and the two models that want them
 *
 * That file has one read slot and one write slot, and both models live here. Rather than turning
 * its single slot into a list - which would let something outside this file install a second model
 * whose order against ours nobody has decided - the chaining is done here, one function per
 * direction, asking each model in turn. The order matters only where two models claim the same
 * offset, and they do not: the MEC model answers CP_HQD_*, the SDMA one answers SDMAx_GFX_RB_*.
 * ------------------------------------------------------------------------------------------- */
static int backend_read_dispatch(u32 byte_offset, u32 *value)
{
	if (backend_mec_answer(byte_offset, value))
		return 1;
	return sdma_answer(byte_offset, value);
}

static void backend_write_dispatch(u32 byte_offset, u32 value)
{
	backend_mec_observe(byte_offset, value);
	/* The SDMA model has nothing to observe: point 3 of its header is that a write to a pointer
	 * register does not reach the engine, and the doorbell is where it does follow along. */
}

static void hooks_refresh(void)
{
	int on = g_mec_on || g_sdma_reg_count != 0;

	backend_set_read_hook(on ? backend_read_dispatch : NULL);
	backend_set_write_hook(on ? backend_write_dispatch : NULL);
}

void bc250_shim_wdoorbell64(struct amdgpu_device *adev, unsigned int index, unsigned long long value)
{
	unsigned int i;
	struct ring_slot *slot = NULL;
	struct amdgpu_ring *ring;
	u64 at;

	(void)adev;
	doorbell_record(index, value, 64);

	for (i = 0; i < g_ring_count; i++) {
		if (g_ring[i].ring->doorbell_index == index) {
			slot = &g_ring[i];
			break;
		}
	}
	if (slot == NULL)
		return;                 /* a ring the test did not register: nothing to decode */

	ring = slot->ring;
	if (ring->ring == NULL)
		return;

	/* The MEC model faulted on this ring's slot: the engine is off in the weeds and this queue
	 * executes nothing, so a ring test on it times out. That is how E12 run 002 presented. */
	if (slot->dead)
		return;

	/* An SDMA doorbell carries the write pointer in BYTES - sdma_v5_0_ring_set_wptr() rings it
	 * with ring->wptr << 2 - so it is brought back to dwords before anything below counts with
	 * it, and the packets are decoded by the other stub.
	 *
	 * Where the engine starts from is the fifth declared model, not the ring: the pointer it
	 * holds survives the teardown and the next bring-up's writes of 0, and it is monotonic, so a
	 * doorbell at or below it says nothing new and executes nothing. backend_mem.h has what E15
	 * measured. What this replaced was the CP rings' rule - a doorbell that does not advance means
	 * the ring was re-initialised, start again at 0 - which unit A refutes for these two engines
	 * and which is why the second bring-up's ring test used to pass here and time out there. */
	if (ring->funcs->type == AMDGPU_RING_TYPE_SDMA) {
		u64 to = value >> 2;

		if (value <= slot->sdma_engine_ptr) {
			g_sdma_ignored++;
			return;
		}

		for (at = slot->sdma_engine_ptr >> 2; at < to; ) {
			unsigned int size = 0;

			if (!g_stub_on)
				break;
			if (!stub_sdma_execute(ring, at, &size) || size == 0)
				break;
			g_stub_hits++;
			at += size;
		}
		slot->sdma_engine_ptr = value;
		slot->sdma_ran = 1;
		slot->decoded_to = to;
		return;
	}

	/* A doorbell that does not advance the write pointer means the ring was re-initialised: the
	 * MQD builders set ring->wptr = 0, exactly as amdgpu_ring_init_mqd() does, and MAP_QUEUES then
	 * gives the CP an MQD whose cp_hqd_pq_rptr is 0 too, so the CP starts reading from the
	 * beginning again. This does the same.
	 *
	 * The test is `<=`, not `<`, and that matters: a compute ring's only submission is a 3-dword
	 * ring test, so after a teardown and a second bring-up its write pointer is 3 again - the same
	 * value, not a smaller one. With `<` the decoder saw nothing new and every ring test in the
	 * second bring-up timed out. `<=` is sound because a doorbell is only ever rung after the
	 * write pointer has advanced, so a value that has not advanced cannot mean anything else. */
	if (value <= slot->decoded_to)
		slot->decoded_to = 0;

	/* The doorbell value is the write pointer, counting dwords on the CP rings. */
	for (at = slot->decoded_to; at < value; ) {
		u32 header = ring->ring[(size_t)(at & ring->buf_mask)];
		unsigned int count, body, k;
		struct backend_packet *p;

		/* The pad amdgpu_ring_insert_nop() writes is ring->funcs->nop, which on the CP rings
		 * is 0xffff1000: a type-3 header whose count field is 0x3fff. Decoding it as a packet
		 * would step 16 KB forward and lose everything behind it, so it is recognised as the
		 * one-dword filler it is, exactly as the dump in replay_gfx.c does. */
		if (header == ring->funcs->nop) {
			at++;
			continue;
		}
		if (CP_PACKET_GET_TYPE(header) != PACKET_TYPE3) {
			at++;
			continue;
		}

		count = CP_PACKET_GET_COUNT(header);
		body = count + 1u;      /* a PACKET3 is one header plus count + 1 body dwords */

		/* Decoded into a local and then logged, rather than decoded into the log. The log is
		 * bounded and the CP is not: a run with more packets than MAX_PACKETS would otherwise
		 * stop EXECUTING them too, and a ring test that is never answered looks exactly like
		 * a ring test the driver built wrongly. */
		{
			struct backend_packet decoded;

			p = &decoded;
			memset(p, 0, sizeof(*p));
			p->doorbell_index = index;
			p->opcode = CP_PACKET3_GET_OPCODE(header);
			p->count = count;
			p->first_dword = (unsigned int)(at & ring->buf_mask);
			p->body_dwords = body < 8u ? body : 8u;
			for (k = 0; k < p->body_dwords; k++)
				p->body[k] = ring->ring[(size_t)((at + 1u + k) & ring->buf_mask)];

			if (g_packet_count < MAX_PACKETS)
				g_packet[g_packet_count++] = *p;

			if (g_stub_on)
				g_stub_hits += (unsigned int)stub_execute(p, ring);
		}

		at += 1u + body;
	}
	slot->decoded_to = value;
	mec_note_consumed(ring, value);

	/* Where the CP leaves this queue's read pointer: at the write pointer, because it has just
	 * consumed everything. That is what unit A's queues idle at after the ring tests (fact M40,
	 * rptr == wptr != 0), and it is the value the next bring-up's MQD would sample if nothing put
	 * it back. Only the queues with an HQD: the graphics ring's pointer is CP_RB0_RPTR, a
	 * different register with no selection behind it. */
	if (ring->funcs->type == AMDGPU_RING_TYPE_COMPUTE ||
	    ring->funcs->type == AMDGPU_RING_TYPE_KIQ) {
		slot->hqd_rptr = (u32)(value & ring->buf_mask);
		slot->hqd_known = 1;
	}
}
