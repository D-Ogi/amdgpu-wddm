@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
set TEMP=P:\bc-250\scratch\tmp
set TMP=%TEMP%
cl /nologo /TC /W3 /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\um /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\shared /FoP:\BC-250\scratch\m12\scalar-alias-order2\order-test.obj /FeP:\BC-250\scratch\m12\scalar-alias-order2\order-test.exe P:\BC-250\scratch\m12\scalar-alias-order2\order-test.c
if errorlevel 1 exit /b 1
P:\BC-250\scratch\m12\scalar-alias-order2\order-test.exe
exit /b %errorlevel%
