@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
set TEMP=P:\bc-250\scratch\tmp
set TMP=%TEMP%
set PYTHONPATH=P:\bc-250\scratch\py
set CMAKE_BUILD_PARALLEL_LEVEL=6
C:\msys64\mingw64\bin\cmake.exe -S P:\bc-250\scratch\m12\cts-release-src -B P:\bc-250\scratch\m12\cts-release-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DDEQP_DISABLE_VK_VIDEO_TESTS=ON -DDEQP_TARGET=default -DCMAKE_DISABLE_FIND_PACKAGE_ZLIB=ON -DCMAKE_DISABLE_FIND_PACKAGE_PNG=ON -DCMAKE_IGNORE_PREFIX_PATH=C:/msys64/mingw64
if errorlevel 1 exit /b 1
C:\msys64\mingw64\bin\cmake.exe --build P:\bc-250\scratch\m12\cts-release-build --target deqp-vk --parallel 6
