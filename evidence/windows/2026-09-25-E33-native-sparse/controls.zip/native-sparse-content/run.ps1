
$ErrorActionPreference='Stop'
$root='C:\BC250\m12\native-sparse-content'
$cli='C:\BC250\m9\candidate07147\client\bc250kmd_cli.exe'
if(Test-Path "$root\result.json"){throw 'Existing result'}
if((Invoke-RestMethod http://127.0.0.1:2250/flags).stop){throw 'Owner STOP'}
if(@(Get-ScheduledTask BC250-M12-* | Where-Object State -in @('Running','Queued')).Count){throw 'Active M12 test'}
if((Get-FileHash "$root\native-content.exe").Hash -ne '376DE466A9BD02BF788970AC3A5FA3DD8DAEFF364C336211500679B755172A6B'){throw 'Hash mismatch'}
$clock=& $cli clock read | Out-String
$health=& $cli health read | Out-String
$clock | Set-Content "$root\clock-before.txt"
$health | Set-Content "$root\health-before.txt"
if($clock -notmatch 'MHz=1000 VID=116 temperature_mc=(\d+) ready=1' -or [int]$Matches[1] -ge 85000){throw 'Clock/thermal gate'}
if($health -notmatch 'flags=15 generation=\d+ epoch=\d+'){throw 'Health gate'}
$begin=[DateTime]::UtcNow.ToString('o')
$p=Start-Process "$root\native-content.exe" -WindowStyle Hidden -PassThru -RedirectStandardOutput "$root\stdout.txt" -RedirectStandardError "$root\stderr.txt"
$keep=$p.Handle
if(-not $p.WaitForExit(35000)){Stop-Process -Id $p.Id -Force;throw 'External deadline'}
@{start_utc=$begin;end_utc=[DateTime]::UtcNow.ToString('o');native_exit=$p.ExitCode;exe_sha256=(Get-FileHash "$root\native-content.exe").Hash} | ConvertTo-Json | Set-Content "$root\result.json"
& $cli clock read | Set-Content "$root\clock-after.txt"
& $cli health read | Set-Content "$root\health-after.txt"
Get-Content "$root\result.json"
Get-Content "$root\stdout.txt"
Get-Content "$root\health-after.txt"
