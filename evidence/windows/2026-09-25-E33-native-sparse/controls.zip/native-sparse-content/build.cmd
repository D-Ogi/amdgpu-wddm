@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
set TEMP=P:\bc-250\scratch\tmp
set TMP=%TEMP%
cl /nologo /W3 /O2 /MT /D_CRT_SECURE_NO_WARNINGS /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\um /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\shared /FoP:\bc-250\scratch\m12\native-sparse-content\native-content.obj /FeP:\bc-250\scratch\m12\native-sparse-content\native-content.exe P:\bc-250\scratch\m12\native-sparse-content\native-content.c /link gdi32.lib
exit /b %errorlevel%
