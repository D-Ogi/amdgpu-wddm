
#define main kmtprobe_original_main
#include "../../../bc250-win/tools/win/kmtprobe/kmtprobe.c"
#undef main
#include <stdint.h>
#include <stdbool.h>
#include <assert.h>
#define VK_SUCCESS 0
#define VK_ERROR_DEVICE_LOST -4
#define VK_ERROR_OUT_OF_HOST_MEMORY -1
typedef int VkResult;
enum amd_ip_type {AMD_IP_GFX=0};
struct vk_sync_wait {uint64_t wait_value;D3DKMT_HANDLE handle;};
struct radv_winsys_submit_info {enum amd_ip_type ip_type;uint32_t queue_index;};
struct radeon_winsys_ctx {int unused;};
struct radeon_winsys {VkResult (*cs_submit)(struct radeon_winsys_ctx*,const struct radv_winsys_submit_info*,uint32_t,const struct vk_sync_wait*,uint32_t,const void*);};
struct util_dynarray {void *data;unsigned size;};
static void util_dynarray_clear(struct util_dynarray *p){p->size=0;}
static void *util_dynarray_grow_bytes(struct util_dynarray *p,unsigned count,size_t size){
 unsigned old=p->size;p->data=realloc(p->data,old+count*size);assert(p->data);p->size+=(unsigned)(count*size);return (char*)p->data+old;
}
#define util_dynarray_num_elements(p,type) ((p)->size/sizeof(type))
struct vk_wddm2_fence {uint32_t handle;uint64_t wait_value;};
struct radv_wddm2_queue {uint32_t context_h,handle;struct vk_wddm2_fence vm_fence;struct util_dynarray sparse_ops;bool sparse_batch_active;};
struct radv_wddm2_ctx {struct radeon_winsys_ctx base;struct {struct radv_wddm2_queue queue;} per_ip[1];};
struct radv_wddm2_winsys {struct radeon_winsys base;uint32_t device_h;};
struct radv_wddm2_bo {struct {uint64_t va;uint32_t handle;} base;};
static struct radv_wddm2_winsys *radv_wddm2_winsys(struct radeon_winsys *p){return (void*)p;}
static NTSTATUS NativeStatus(const char *name,NTSTATUS status){return Report(name,status);}
#define WDDM2_DISPATCH(call) NativeStatus(#call,D3DKMT##call)
static VkResult NativeWaits(struct radeon_winsys_ctx *_ctx,const struct radv_winsys_submit_info *submit,
                           uint32_t count,const struct vk_sync_wait *waits,uint32_t signal_count,const void *signals)
{
    struct radv_wddm2_ctx *ctx=(void*)_ctx;
    if(!count)return VK_SUCCESS;
    assert(count==1 && signal_count==0);
    D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMGPU wait={0};
    wait.hContext=ctx->per_ip[submit->ip_type].queue.context_h;
    wait.ObjectCount=1;wait.ObjectHandleArray=&waits[0].handle;wait.MonitoredFenceValueArray=&waits[0].wait_value;
    return NT_SUCCESS(Report("Application GPU wait",D3DKMTWaitForSynchronizationObjectFromGpu(&wait)))?VK_SUCCESS:VK_ERROR_DEVICE_LOST;
}
static BOOL CpuRelease(D3DKMT_HANDLE device,D3DKMT_HANDLE handle)
{
    UINT64 value=1;
    D3DKMT_SIGNALSYNCHRONIZATIONOBJECTFROMCPU signal={0};
    signal.hDevice=device;signal.ObjectCount=1;signal.ObjectHandleArray=&handle;signal.FenceValueArray=&value;
    return NT_SUCCESS(Report("Application CPU signal",D3DKMTSignalSynchronizationObjectFromCpu(&signal)));
}
static VkResult
radv_wddm2_virtual_bind_begin(struct radeon_winsys *_ws, struct radeon_winsys_ctx *_ctx,
                             enum amd_ip_type ip_type)
{
   struct radv_wddm2_ctx *ctx = (struct radv_wddm2_ctx *)_ctx;
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;

   /* RADV externally serializes submission to each advertised hardware queue. */
   if (queue->sparse_batch_active || !queue->context_h || !queue->vm_fence.handle)
      return VK_ERROR_DEVICE_LOST;
   util_dynarray_clear(&queue->sparse_ops);
   queue->sparse_batch_active = true;
   return VK_SUCCESS;
}

static VkResult
radv_wddm2_virtual_bind_append(struct radv_wddm2_ctx *ctx, enum amd_ip_type ip_type,
                              const D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION *op)
{
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;
   if (!queue->sparse_batch_active)
      return VK_ERROR_DEVICE_LOST;
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION *dst =
      util_dynarray_grow_bytes(&queue->sparse_ops, 1, sizeof(*op));
   if (!dst)
      return VK_ERROR_OUT_OF_HOST_MEMORY;
   *dst = *op;
   return VK_SUCCESS;
}

static VkResult
radv_wddm2_virtual_bind_end(struct radeon_winsys *_ws, struct radeon_winsys_ctx *_ctx,
                           enum amd_ip_type ip_type, uint32_t queue_index,
                           uint32_t wait_count, const struct vk_sync_wait *waits, bool commit)
{
   struct radv_wddm2_winsys *ws = radv_wddm2_winsys(_ws);
   struct radv_wddm2_ctx *ctx = (struct radv_wddm2_ctx *)_ctx;
   struct radv_wddm2_queue *queue = &ctx->per_ip[ip_type].queue;
   VkResult result = VK_SUCCESS;
   NTSTATUS status;

   if (!queue->sparse_batch_active)
      return VK_ERROR_DEVICE_LOST;
   queue->sparse_batch_active = false;
   if (!commit)
      goto done;

   /* An empty GPU submission queues application waits without a CPU wait.
    * The boundary signal below follows both those waits and earlier rendering.
    */
   const struct radv_winsys_submit_info submit = {
      .ip_type = ip_type,
      .queue_index = queue_index,
   };
   result = _ws->cs_submit(_ctx, &submit, wait_count, waits, 0, NULL);
   if (result != VK_SUCCESS)
      goto done;

   const unsigned count =
      util_dynarray_num_elements(&queue->sparse_ops, D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION);
   if (!count)
      goto done;
   if (queue->vm_fence.wait_value > UINT64_MAX - 2) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }
   const uint64_t boundary = queue->vm_fence.wait_value + 1;
   const uint64_t completed = boundary + 1;
   if (queue->handle) {
      const D3DKMT_SUBMITSIGNALSYNCOBJECTSTOHWQUEUE signal = {
         .BroadcastHwQueueCount = 1,
         .BroadcastHwQueueArray = &queue->handle,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .FenceValueArray = &boundary,
      };
      status = WDDM2_DISPATCH(SubmitSignalSyncObjectsToHwQueue(&signal));
   } else {
      const D3DKMT_SIGNALSYNCHRONIZATIONOBJECTFROMGPU2 signal = {
         .BroadcastContextCount = 1,
         .BroadcastContextArray = &queue->context_h,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .MonitoredFenceValueArray = &boundary,
      };
      status = WDDM2_DISPATCH(SignalSynchronizationObjectFromGpu2(&signal));
   }
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }

   /* WDK26100 D3DKMT_UPDATEGPUVIRTUALADDRESS: wait for FenceValue, then
    * signal FenceValue+1 from the paging companion context. The runtime owns
    * backing residency while these mapping operations are queued.
    */
   const D3DKMT_UPDATEGPUVIRTUALADDRESS update = {
      .hDevice = ws->device_h,
      .hContext = queue->context_h,
      .hFenceObject = queue->vm_fence.handle,
      .FenceValue = boundary,
      .Operations = queue->sparse_ops.data,
      .NumOperations = count,
   };
   status = WDDM2_DISPATCH(UpdateGpuVirtualAddress(&update));
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }

   if (queue->handle) {
      const D3DKMT_SUBMITWAITFORSYNCOBJECTSTOHWQUEUE wait = {
         .hHwQueue = queue->handle,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .FenceValueArray = &completed,
      };
      status = WDDM2_DISPATCH(SubmitWaitForSyncObjectsToHwQueue(&wait));
   } else {
      const D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMGPU wait = {
         .hContext = queue->context_h,
         .ObjectCount = 1,
         .ObjectHandleArray = &queue->vm_fence.handle,
         .MonitoredFenceValueArray = &completed,
      };
      status = WDDM2_DISPATCH(WaitForSynchronizationObjectFromGpu(&wait));
   }
   if (!NT_SUCCESS(status)) {
      result = VK_ERROR_DEVICE_LOST;
      goto done;
   }
   queue->vm_fence.wait_value = completed;

done:
   util_dynarray_clear(&queue->sparse_ops);
   return result;
}

static VkResult
radv_wddm2_virtual_bo_map(struct radv_wddm2_winsys *ws, struct radv_wddm2_ctx *ctx,
                            enum amd_ip_type ip_type, struct radv_wddm2_bo *parent,
                            uint64_t offset, uint64_t size, struct radv_wddm2_bo *bo,
                            uint64_t bo_offset)
{
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION op = {
      .OperationType = D3DDDI_UPDATEGPUVIRTUALADDRESS_MAP_PROTECT,
      .MapProtect = {
         .BaseAddress = parent->base.va + offset,
         .SizeInBytes = size,
         .hAllocation = bo->base.handle,
         .AllocationOffsetInBytes = bo_offset,
         .AllocationSizeInBytes = size,
         .Protection = {
            .Write = 1,
         },
         .DriverProtection = 1,
      },
   };

   return radv_wddm2_virtual_bind_append(ctx, ip_type, &op);
}

static VkResult
radv_wddm2_virtual_bo_unmap(struct radv_wddm2_winsys *ws, struct radv_wddm2_ctx *ctx,
                            enum amd_ip_type ip_type, struct radv_wddm2_bo *parent,
                            uint64_t offset, uint64_t size)
{
   D3DDDI_UPDATEGPUVIRTUALADDRESS_OPERATION op = {
      .OperationType = D3DDDI_UPDATEGPUVIRTUALADDRESS_UNMAP,
      .Unmap = {
         .BaseAddress = parent->base.va + offset,
         .SizeInBytes = size,
         .Protection = {
            .Zero = 1,
         }
      },
   };

   return radv_wddm2_virtual_bind_append(ctx, ip_type, &op);
}



/* PM4 source: Mesa ac_emit_cp_copy_data; field values from imported AMD nvd.h (MIT). */
#undef PACKET_TYPE3
#undef PACKET3
#undef PACKET3_NOP
#undef PACKET3_SET_UCONFIG_REG
#undef PACKET3_SET_UCONFIG_REG_START
#undef PACKET3_SET_UCONFIG_REG_END
#include "../../../bc250-win/driver/amdgpu-import/nvd.h"
#include <emmintrin.h>

static BOOL ReadContent(PROBE *p,PROBE *completion,BUFFER *ib,UINT64 source,
                        UINT64 expected,UINT64 sequence,const char *label)
{
    UINT32 *dw;UINT64 destination=p->Data.MappedVa+131072+sequence*8,observed;
    D3DKMT_SUBMITCOMMAND submit={0};
    if(!LockBuffer(p,ib))return FALSE;
    dw=(UINT32*)ib->Locked;
    /* Six COPY_DATA dwords plus two packet2 NOPs, matching GFX IB alignment. */
    dw[0]=PACKET3(PACKET3_COPY_DATA,4);
    dw[1]=PACKET3_COPY_DATA__SRC_SEL(PACKET3_COPY_DATA__SRC_SEL__TC_L2_OBSOLETE) |
          PACKET3_COPY_DATA__DST_SEL(PACKET3_COPY_DATA__DST_SEL__TC_L2_OBSOLETE) |
          PACKET3_COPY_DATA__COUNT_SEL(PACKET3_COPY_DATA__COUNT_SEL__64_BITS_OF_DATA) |
          PACKET3_COPY_DATA__WR_CONFIRM(PACKET3_COPY_DATA__WR_CONFIRM__WAIT_FOR_CONFIRMATION);
    dw[2]=(UINT32)source;dw[3]=(UINT32)(source>>32);
    dw[4]=(UINT32)destination;dw[5]=(UINT32)(destination>>32);
    dw[6]=BC250_CP_NOP;dw[7]=BC250_CP_NOP;
    _mm_sfence();
    if(!UnlockBuffer(p,ib))return FALSE;
    submit.Commands=ib->MappedVa;submit.CommandLength=32;
    submit.BroadcastContextCount=1;submit.BroadcastContext[0]=p->hContext;
    if(!NT_SUCCESS(Report("Content COPY_DATA SubmitCommand",D3DKMTSubmitCommand(&submit)))||
       !StepSignalFence(completion,sequence)||!StepWaitFence(completion,sequence))return FALSE;
    if(!LockBuffer(p,&p->Data))return FALSE;
    observed=*(volatile UINT64*)((char*)p->Data.Locked+131072+sequence*8);
    Note("CONTENT %s observed=0x%016llX expected=0x%016llX %s",
         label,observed,expected,observed==expected?"PASS":"FAIL");
    if(!UnlockBuffer(p,&p->Data))return FALSE;
    return observed==expected;
}

int main(void)
{
    PROBE p={0},completion={0};BUFFER ib={0};
    BOOL ok=FALSE,released=FALSE;
    const UINT64 a=0x13579BDF2468ACE0ull,b=0xFEDCBA9876543210ull;
    struct radv_wddm2_winsys ws={0};struct radv_wddm2_ctx ctx={0};
    struct radv_wddm2_queue *q=&ctx.per_ip[AMD_IP_GFX].queue;
    struct radv_wddm2_bo parent={0},physical={0};
    D3DKMT_CREATESYNCHRONIZATIONOBJECT2 input={0};
    D3DKMT_CREATECONTEXTVIRTUAL context={0};
    struct vk_sync_wait app_wait={0};D3DDDI_MAPGPUVIRTUALADDRESS zero={0};
    p.Opt.Match="bc250";p.Opt.FenceTimeoutMs=5000;
    p.Data.Name="physical-control";p.Data.Size=196608;p.Data.RequestedVa=0x200000000ull;
    ib.Name="copy-ib";ib.Size=65536;ib.RequestedVa=0x200040000ull;
    p.Command.Name="virtual-control";p.Command.Size=65536;p.Command.RequestedVa=0x200060000ull;
    setvbuf(stdout,NULL,_IONBF,0);if(!StartWatchdog(30000))return 2;
    if(!StepFindAdapter(&p)||!StepOpenAdapter(&p)||!StepCreateDevice(&p)||!StepCreatePagingQueue(&p)||
       !StepCreateAllocation(&p,&p.Data)||!StepMakeResident(&p,&p.Data)||!StepReserveVa(&p,&p.Data)||
       !StepMapVa(&p,&p.Data)||!StepReserveVa(&p,&p.Command)||
       !StepCreateAllocation(&p,&ib)||!StepMakeResident(&p,&ib)||!StepReserveVa(&p,&ib)||!StepMapVa(&p,&ib))goto done;
    if(!LockBuffer(&p,&p.Data))goto done;
    memset(p.Data.Locked,0xAC,(size_t)p.Data.Size);
    *(volatile UINT64*)p.Data.Locked=a;
    *(volatile UINT64*)((char*)p.Data.Locked+65536)=b;
    _mm_sfence();if(!UnlockBuffer(&p,&p.Data))goto done;
    zero.hPagingQueue=p.hPagingQueue;zero.BaseAddress=p.Command.ReservedBase;zero.SizeInPages=16;zero.Protection.Zero=1;
    if(!NT_SUCCESS(Report("Initial zero mapping",D3DKMTMapGpuVirtualAddress(&zero)))||
       !WaitPagingFence(&p,zero.PagingFenceValue,"initial zero"))goto done;
    context.hDevice=p.hDevice;context.NodeOrdinal=0;context.ClientHint=D3DKMT_CLIENTHINT_VULKAN;
    if(!NT_SUCCESS(Report("CreateContextVirtual (normal TDR policy)",D3DKMTCreateContextVirtual(&context))))goto done;
    p.hContext=context.hContext;if(!StepCreateFence(&p))goto done;
    p.WaitEvent=CreateEventW(NULL,FALSE,FALSE,NULL);if(!p.WaitEvent)goto done;
    completion.hDevice=p.hDevice;completion.hContext=p.hContext;completion.WaitEvent=p.WaitEvent;completion.Opt.FenceTimeoutMs=5000;
    if(!StepCreateFence(&completion))goto done;
    if(!ReadContent(&p,&completion,&ib,p.Data.MappedVa,a,1,"physical-A")||
       !ReadContent(&p,&completion,&ib,p.Data.MappedVa+65536,b,2,"physical-B"))goto done;
    if(!ReadContent(&p,&completion,&ib,p.Command.ReservedBase,0,3,"initial-zero"))goto done;
    input.hDevice=p.hDevice;input.Info.Type=D3DDDI_MONITORED_FENCE;input.Info.MonitoredFence.EngineAffinity=1;
    if(!NT_SUCCESS(Report("Create application fence",D3DKMTCreateSynchronizationObject2(&input))))goto done;
    ws.base.cs_submit=NativeWaits;ws.device_h=p.hDevice;q->context_h=p.hContext;q->vm_fence.handle=p.hFence;
    parent.base.va=p.Command.ReservedBase;physical.base.va=p.Data.MappedVa;physical.base.handle=p.Data.hAllocation;
    app_wait.handle=input.hSyncObject;app_wait.wait_value=1;
    if(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)||
       radv_wddm2_virtual_bo_map(&ws,&ctx,AMD_IP_GFX,&parent,0,65536,&physical,0)||
       radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,1,&app_wait,true))goto done;
    Sleep(20);printf("DELAYED_WAIT vm_fence=%llu expected=0\n",*p.FenceCpuVa);
    if(*p.FenceCpuVa!=0||!CpuRelease(p.hDevice,input.hSyncObject))goto done;
    released=TRUE;if(!StepWaitFence(&p,2))goto done;
    if(!ReadContent(&p,&completion,&ib,parent.base.va,a,4,"alias-A"))goto done;
    if(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)||
       radv_wddm2_virtual_bo_map(&ws,&ctx,AMD_IP_GFX,&parent,0,65536,&physical,65536)||
       radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,0,NULL,true)||
       !StepWaitFence(&p,4))goto done;
    if(!ReadContent(&p,&completion,&ib,parent.base.va,b,5,"rebind-B"))goto done;
    if(radv_wddm2_virtual_bind_begin(&ws.base,&ctx.base,AMD_IP_GFX)||
       radv_wddm2_virtual_bo_unmap(&ws,&ctx,AMD_IP_GFX,&parent,0,65536)||
       radv_wddm2_virtual_bind_end(&ws.base,&ctx.base,AMD_IP_GFX,0,0,NULL,true)||
       !StepWaitFence(&p,6))goto done;
    if(!ReadContent(&p,&completion,&ib,parent.base.va,0,6,"unmapped-zero"))goto done;
    puts("ZERO_READ PASS through CP COPY_DATA; shader and write-discard semantics untested");
    ok=TRUE;
done:
    if(input.hSyncObject&&!released)CpuRelease(p.hDevice,input.hSyncObject);
    if(input.hSyncObject){D3DKMT_DESTROYSYNCHRONIZATIONOBJECT d={0};d.hSyncObject=input.hSyncObject;Report("Destroy application fence",D3DKMTDestroySynchronizationObject(&d));}
    if(completion.hFence){D3DKMT_DESTROYSYNCHRONIZATIONOBJECT d={0};d.hSyncObject=completion.hFence;Report("Destroy copy fence",D3DKMTDestroySynchronizationObject(&d));}
    TeardownBuffer(&p,&ib);Teardown(&p);free(q->sparse_ops.data);SetEvent(g_Done);
    puts(ok?"RESULT PASS":"RESULT FAIL");return ok?0:1;
}
