
#define main kmtprobe_original_main
#include "../../../bc250-win/tools/win/kmtprobe/kmtprobe.c"
#undef main

int main(void)
{
    PROBE probe;
    D3DDDI_MAPGPUVIRTUALADDRESS zero;
    NTSTATUS status;
    BOOL ok = FALSE;
    ZeroMemory(&probe, sizeof(probe));
    probe.Opt.Match = "bc250";
    probe.Opt.FenceTimeoutMs = 5000;
    probe.Data.Name = "physical-control";
    probe.Data.Size = 65536;
    probe.Data.RequestedVa = 0x200000000ull;
    probe.Command.Name = "zero-range";
    probe.Command.Size = 65536;
    probe.Command.RequestedVa = 0x200020000ull;
    setvbuf(stdout, NULL, _IONBF, 0);
    if (!StartWatchdog(30000)) return 2;
    if (!StepFindAdapter(&probe) || !StepOpenAdapter(&probe) ||
        !StepQueryCaps(&probe) || !StepCreateDevice(&probe) ||
        !StepCreatePagingQueue(&probe) ||
        !StepCreateAllocation(&probe, &probe.Data) ||
        !StepMakeResident(&probe, &probe.Data) ||
        !StepReserveVa(&probe, &probe.Data) ||
        !StepMapVa(&probe, &probe.Data))
        goto done;
    puts("CONTROL physical allocation mapping and paging fence PASS");
    if (!StepReserveVa(&probe, &probe.Command)) goto done;
    ZeroMemory(&zero, sizeof(zero));
    zero.hPagingQueue = probe.hPagingQueue;
    zero.BaseAddress = probe.Command.ReservedBase;
    zero.SizeInPages = probe.Command.Size / GPU_PAGE_SIZE;
    zero.Protection.Zero = 1;
    status = Report("D3DKMTMapGpuVirtualAddress Protection.Zero", D3DKMTMapGpuVirtualAddress(&zero));
    if (!NT_SUCCESS(status)) goto done;
    probe.Command.MappedVa = zero.VirtualAddress;
    if (zero.VirtualAddress != zero.BaseAddress ||
        !WaitPagingFence(&probe, zero.PagingFenceValue, "Protection.Zero"))
        goto done;
    puts("ZERO_MAP initial64KiB zero mapping and paging fence PASS; no GPU read/write performed");
    ok = TRUE;
done:
    Teardown(&probe);
    SetEvent(g_Done);
    puts(ok ? "RESULT PASS" : "RESULT FAIL");
    return ok ? 0 : 1;
}
