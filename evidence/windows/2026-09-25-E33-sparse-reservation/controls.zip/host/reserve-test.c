
#include <windows.h>
#include <d3dkmthk.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define NT_SUCCESS(s) ((s)>=0)
#define MAX2(a,b) ((a)>(b)?(a):(b))
#define align64(a,b) (((a)+(b)-1)&~((uint64_t)(b)-1))
#define CALLOC_STRUCT(t) ((struct t*)calloc(1,sizeof(struct t)))
#define FREE free
#define VK_SUCCESS 0
#define VK_ERROR_OUT_OF_HOST_MEMORY -1
#define VK_ERROR_OUT_OF_DEVICE_MEMORY -2
typedef int VkResult;
enum radeon_bo_flag { RADEON_FLAG_32BIT=1, RADEON_FLAG_REPLAYABLE=2 };
enum radeon_bo_domain { RADEON_DOMAIN_VRAM=1 };
#define RADV_WDDM2_HEAP_START 0x200000000ull
#define RADV_WDDM2_32BIT_HEAP_START 0x100000000ull
#define RADV_WDDM2_REPLAY_HEAP_START 0x500000000000ull
struct radeon_winsys {int unused;};
struct radeon_winsys_bo {enum radeon_bo_domain initial_domain;bool is_virtual;uint64_t va,size;};
struct radv_wddm2_winsys {struct radeon_winsys base;D3DKMT_HANDLE adapter_h,paging_queue_h,device_h,paging_fence_h;};
struct radv_wddm2_bo {struct radeon_winsys_bo base;struct radv_wddm2_winsys *ws;enum radeon_bo_flag flags;uint64_t reserved_va,reserved_size;};
static struct radv_wddm2_winsys *radv_wddm2_winsys(struct radeon_winsys *p){return (struct radv_wddm2_winsys*)p;}
static uint64_t chosen, mapped, reserved, reservation_size, released, release_size;
static unsigned phase;
static NTSTATUS mock_ReserveGpuVirtualAddress(D3DDDI_RESERVEGPUVIRTUALADDRESS *p){
 assert(phase++==0);assert(p->hAdapter==11);
 assert(p->Size%65536==0);assert(!p->Reserved0 && !p->Reserved1);
 reserved=p->BaseAddress?p->BaseAddress:chosen;reservation_size=p->Size;
 assert(p->BaseAddress || (reserved>=p->MinimumAddress && reserved+p->Size<=p->MaximumAddress));
 p->VirtualAddress=reserved;return 0;
}
static NTSTATUS mock_MapGpuVirtualAddress(D3DDDI_MAPGPUVIRTUALADDRESS *p){
 assert(phase++==1);assert(p->hPagingQueue==22 && !p->hAllocation && p->Protection.Zero);
 mapped=p->BaseAddress;assert(mapped>=reserved && mapped+p->SizeInPages*4096<=reserved+reservation_size);
 p->PagingFenceValue=77;return 0x103; /* STATUS_PENDING is success; it still requires a wait. */
}
static NTSTATUS mock_WaitForSynchronizationObjectFromCpu(const D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMCPU *p){
 assert(phase++==2);assert(p->hDevice==33 && p->ObjectCount==1);
 assert(*p->ObjectHandleArray==44 && *p->FenceValueArray==77);return 0;
}
static NTSTATUS mock_FreeGpuVirtualAddress(const D3DKMT_FREEGPUVIRTUALADDRESS *p){
 assert(phase++==3);assert(p->hAdapter==11);released=p->BaseAddress;release_size=p->Size;return 0;
}
#define WDDM2_DISPATCH(call) mock_##call
static uint64_t
radv_wddm2_reserve_va_range(struct radv_wddm2_winsys *ws, struct radv_wddm2_bo *bo,
                           uint64_t size, unsigned alignment, enum radeon_bo_flag flags,
                           uint64_t address)
{
   /* WDDM reservations use 64 KiB granularity. Preserve the whole reservation
    * when a larger resource alignment requires an aligned interior address.
    * The OS owns VA placement; its reservation also excludes ordinary BO maps.
    * Local WDK26100: D3DDDI_RESERVEGPUVIRTUALADDRESS / FreeGpuVirtualAddress.
    */
   const unsigned granularity = 65536;
   uint64_t min, max;
   NTSTATUS status;

   alignment = MAX2(alignment, granularity);
   if (!size || (size & (granularity - 1)) ||
       (alignment & (alignment - 1)) || (address & (alignment - 1)) ||
       size > UINT64_MAX - (alignment - granularity))
      return 0;

   if (flags & RADEON_FLAG_32BIT) {
      min = RADV_WDDM2_32BIT_HEAP_START;
      max = RADV_WDDM2_HEAP_START;
   } else if (flags & RADEON_FLAG_REPLAYABLE) {
      min = RADV_WDDM2_REPLAY_HEAP_START;
      max = min + (4ull << 32);
   } else {
      min = RADV_WDDM2_HEAP_START;
      max = RADV_WDDM2_REPLAY_HEAP_START;
   }

   D3DDDI_RESERVEGPUVIRTUALADDRESS reserve = {
      /* The current D3DKMT contract uses hAdapter, not obsolete hPagingQueue. */
      .hAdapter = ws->adapter_h,
      .BaseAddress = address,
      .MinimumAddress = min,
      .MaximumAddress = max,
      .Size = size + (address ? 0 : alignment - granularity),
   };
   status = WDDM2_DISPATCH(ReserveGpuVirtualAddress(&reserve));
   if (!NT_SUCCESS(status))
      return 0;

   const uint64_t va = align64(reserve.VirtualAddress, alignment);
   D3DDDI_MAPGPUVIRTUALADDRESS map = {
      .hPagingQueue = ws->paging_queue_h,
      .BaseAddress = va,
      .SizeInPages = size / 4096,
      .Protection = {
         .Zero = 1,
      },
   };
   status = WDDM2_DISPATCH(MapGpuVirtualAddress(&map));
   if (NT_SUCCESS(status)) {
      /* Initial zero mapping is asynchronous, just like physical BO mapping.
       * Do not return the BO before that paging operation has retired. */
      const D3DKMT_WAITFORSYNCHRONIZATIONOBJECTFROMCPU wait = {
         .hDevice = ws->device_h,
         .ObjectCount = 1,
         .ObjectHandleArray = &ws->paging_fence_h,
         .FenceValueArray = &map.PagingFenceValue,
      };
      status = WDDM2_DISPATCH(WaitForSynchronizationObjectFromCpu(&wait));
   }
   if (!NT_SUCCESS(status)) {
      const D3DKMT_FREEGPUVIRTUALADDRESS release = {
         .hAdapter = ws->adapter_h,
         .BaseAddress = reserve.VirtualAddress,
         .Size = reserve.Size,
      };
      WDDM2_DISPATCH(FreeGpuVirtualAddress(&release));
      return 0;
   }

   bo->reserved_va = reserve.VirtualAddress;
   bo->reserved_size = reserve.Size;
   return va;
}

static VkResult
radv_wddm2_virtual_bo_create(struct radeon_winsys *_ws, uint64_t size, unsigned alignment,
                             enum radeon_bo_domain initial_domain, enum radeon_bo_flag flags,
                             unsigned priority, uint64_t address, struct radeon_winsys_bo **out_bo)
{
   struct radv_wddm2_winsys *ws = radv_wddm2_winsys(_ws);
   struct radv_wddm2_bo *bo;
   VkResult result;

   /* Courtesy for users using NULL to check if they need to destroy the BO. */
   *out_bo = NULL;

   bo = CALLOC_STRUCT(radv_wddm2_bo);
   if (!bo)
      return VK_ERROR_OUT_OF_HOST_MEMORY;

   bo->base.initial_domain = initial_domain;
   bo->ws = ws;
   bo->flags = flags;
   bo->base.is_virtual = true;
   bo->base.size = size;
   bo->base.va = radv_wddm2_reserve_va_range(ws, bo, size, alignment, flags, address);
   if (bo->base.va == 0) {
      result = VK_ERROR_OUT_OF_DEVICE_MEMORY;
      goto error_va_reserve;
   }

   *out_bo = &bo->base;
   return VK_SUCCESS;

error_va_reserve:
   FREE(bo);
   return result;
}

static void release_actual(struct radv_wddm2_winsys *ws,struct radv_wddm2_bo *bo){NTSTATUS status;
   const D3DKMT_FREEGPUVIRTUALADDRESS unmap = {
      .hAdapter = ws->adapter_h,
      .BaseAddress = bo->reserved_va ? bo->reserved_va : bo->base.va,
      .Size = bo->reserved_size ? bo->reserved_size : bo->base.size,
   };
   status = WDDM2_DISPATCH(FreeGpuVirtualAddress(&unmap));
(void)status;}

static void check_case(uint64_t size,unsigned alignment,uint64_t expected_va,uint64_t expected_reserved_size,uint64_t replay) {
 struct radv_wddm2_winsys ws={0};struct radeon_winsys_bo *base=NULL;
 ws.adapter_h=11;ws.paging_queue_h=22;ws.device_h=33;ws.paging_fence_h=44;phase=0;
 VkResult rc=radv_wddm2_virtual_bo_create(&ws.base,size,alignment,RADEON_DOMAIN_VRAM,
     replay?RADEON_FLAG_REPLAYABLE:0,0,replay,&base);
 assert(rc==VK_SUCCESS && phase==3 && base && base->is_virtual && base->size==size);
 struct radv_wddm2_bo *bo=(struct radv_wddm2_bo*)base;
 assert(base->va==expected_va && mapped==expected_va);
 assert(bo->reserved_va==reserved && bo->reserved_size==expected_reserved_size);
 release_actual(&ws,bo);
 assert(phase==4 && released==reserved && release_size==expected_reserved_size);
 free(bo);
}
int main(void){
 chosen=0x200010000ull;
 check_case(65536,65536,0x200010000ull,65536,0);
 check_case(1048576,524288,0x200080000ull,1048576+524288-65536,0);
 check_case(5ull<<30,65536,0x200010000ull,5ull<<30,0);
 check_case(1048576,524288,0x500000080000ull,1048576,0x500000080000ull);
 puts("PASS: 64KiB, interior 512KiB alignment, 5GiB range, exact replay; asynchronous fence precedes return; full reservation released");
 return 0;
}
