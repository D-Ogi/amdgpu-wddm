@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
set TEMP=P:\bc-250\scratch\tmp
set TMP=%TEMP%
cl /nologo /W3 /WX /O2 /MT /D_CRT_SECURE_NO_WARNINGS /I "P:\BC-250\scratch\m12\native-sparse-dma149" /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\um /I P:\bc-250\toolchain\nuget\microsoft.windows.wdk.x64\c\Include\10.0.26100.0\shared /Fo"P:\BC-250\scratch\m12\native-sparse-dma149\native-sparse-control.obj" /Fe"P:\BC-250\scratch\m12\native-sparse-dma149\native-sparse-control.exe" "P:\BC-250\bc250-win\experiments\E33-m12-applications\native_sparse_control.c" /link gdi32.lib
exit /b %errorlevel%
