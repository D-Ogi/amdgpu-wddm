$ErrorActionPreference='Stop'
$root='C:\BC250\m12\native-copy151'
$cli='C:\BC250\m9\candidate07147\client\bc250kmd_cli.exe'
if((Invoke-RestMethod http://127.0.0.1:2250/flags).stop){throw 'Owner STOP'}
$health=& $cli health read | Out-String
if($health -notmatch 'version=0x00070097 flags=15'){throw "Health gate: $health"}
$clock=& $cli clock read | Out-String
if($clock -notmatch 'MHz=1000 VID=116 temperature_mc=(\d+) ready=1' -or [int]$Matches[1] -ge 85000){throw 'Clock/thermal gate'}
$exe="$root\native-sparse-control.exe"
if((Get-FileHash $exe).Hash -ne '7667E298702B36BA4370E59F57762D1B40E328C9C630790793944F397A64C94D'){throw 'Probe hash'}
if((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\bc250kmd\Parameters').EnableNativePteCopy -ne 1){throw 'Native gate closed'}
if(Get-Process deqp-vk,native-sparse-control -ErrorAction SilentlyContinue){throw 'Other test running'}
& $cli log summary | Out-File "$root\before-driver.log"
(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('o') | Set-Content "$root\boot-before.txt"
foreach($mode in @('copy-map')){
 $dir="$root\dma-$mode"
 if(Test-Path $dir){throw 'Existing results'}
 New-Item -ItemType Directory $dir | Out-Null
 $health | Set-Content "$dir\health-before.txt"
 $clock | Set-Content "$dir\clock-before.txt"
 $start=[DateTime]::UtcNow.ToString('o')
 $options=@{FilePath=$exe;WindowStyle='Hidden';PassThru=$true;RedirectStandardOutput="$dir\stdout.txt";RedirectStandardError="$dir\stderr.txt"}
 $options.ArgumentList='--dma --copy-map'
 if($mode -eq 'holes'){$options.ArgumentList='--dma --paired --holes --write-hole'}
 $p=Start-Process @options
 $keep=$p.Handle
 if(-not $p.WaitForExit(35000)){Stop-Process -Id $p.Id -Force;throw 'Probe deadline'}
 $text=[IO.File]::ReadAllText("$dir\stdout.txt")
 @{mode=$mode;start_utc=$start;end_utc=[DateTime]::UtcNow.ToString('o');native_exit=$p.ExitCode;exe_sha256=(Get-FileHash $exe).Hash} | ConvertTo-Json | Set-Content "$dir\result.json"
 $health=& $cli health read | Out-String
 $clock=& $cli clock read | Out-String
 $health | Set-Content "$dir\health-after.txt"
 $clock | Set-Content "$dir\clock-after.txt"
 Get-Content "$dir\result.json"
 $text.Split([char]10) | Where-Object {$_ -match 'CONTENT|RESULT|ZERO_READ|BOUND_READ|monitored fence|COPY_MAPPING|DELAYED_WAIT'}
 if($p.ExitCode -ne 0 -or $text -notmatch 'RESULT PASS'){throw 'Native control failed'}
 if($health -notmatch 'version=0x00070097 flags=15'){throw 'Health changed'}
 if($clock -notmatch 'MHz=1000 VID=116 temperature_mc=(\d+) ready=1' -or [int]$Matches[1] -ge 85000){throw 'Clock/thermal changed'}
}
& $cli log summary | Out-File "$root\control-driver.log"

(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('o') | Set-Content "$root\boot-after.txt"
Select-String "$root\control-driver.log" -Pattern 'native PTE copies|paging operation|no TDR' | ForEach-Object {$_.Line}
