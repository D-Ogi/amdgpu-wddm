from pathlib import Path
import sys
r=Path('P:/bc-250');w=r/'scratch/m12/native-copy151';sys.path.insert(0,str(r/'bc250-win/tools/win'));from target import Target
t=Target();t.push([str(r/'scratch/m12/native-copy151/native-sparse-control.exe')],r'C:\BC250\m12\native-copy151')
try:p=t.run_script(str(w/'run.ps1'),timeout=55)
except Exception as e:
 print(type(e).__name__);raise SystemExit(1)
(w/'run.log').write_text(p.stdout+p.stderr)
print(p.stdout);print(p.stderr);raise SystemExit(p.returncode)
