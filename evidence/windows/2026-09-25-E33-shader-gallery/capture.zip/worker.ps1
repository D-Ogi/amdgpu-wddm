param([string]$Root='C:\BC250\m12\shader-gallery')
$ErrorActionPreference='Stop'
$env:VK_DRIVER_FILES='C:\BC250\m12\mesa05-alias2\radeon_icd.json'
$env:VK_LOADER_DEBUG='driver'
$env:BC250_TRACE_SUBMITS='0'
Remove-Item Env:RADV_EXPERIMENTAL -ErrorAction SilentlyContinue
$env:TEMP='C:\BC250\tmp';$env:TMP=$env:TEMP
$out="$Root\capture"
New-Item -ItemType Directory $out -ErrorAction Stop | Out-Null
@{utc=[DateTime]::UtcNow.ToString('o');boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('o');icd=(Get-FileHash 'C:\BC250\m12\mesa05-alias2\vulkan_radeon.dll').Hash;compute=(Get-FileHash "$Root\shader-gallery-compute.exe").Hash;shader=(Get-FileHash "$Root\gallery.spv").Hash} | ConvertTo-Json | Set-Content "$out\identity.json"
$si=[Diagnostics.ProcessStartInfo]::new()
$si.FileName="$Root\shader-gallery-compute.exe";$si.Arguments="$Root $out"
$si.UseShellExecute=$false;$si.CreateNoWindow=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
$p=[Diagnostics.Process]::Start($si);$stdout=[IO.File]::Create("$out\compute.out");$stderr=[IO.File]::Create("$out\compute.err")
$so=$p.StandardOutput.BaseStream.CopyToAsync($stdout);$se=$p.StandardError.BaseStream.CopyToAsync($stderr)
$modules=@{};$watch=[Diagnostics.Stopwatch]::StartNew()
try {
 while(-not $p.HasExited -and $watch.Elapsed.TotalSeconds -lt 45){
  try {foreach($m in $p.Modules){if($m.ModuleName -match 'vulkan'){$modules[$m.FileName]=1}}}catch{}
  Start-Sleep -Milliseconds 10;$p.Refresh()
 }
 if(-not $p.HasExited){$p.Kill();throw 'Compute deadline'}
 if(-not $so.Wait(2000) -or -not $se.Wait(2000)){throw 'Output drain'}
 @{exit_code=$p.ExitCode;modules=@($modules.Keys);utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content "$out\process.json"
 if($p.ExitCode -ne 0){throw 'Compute failed'}
 if(-not $modules.ContainsKey('C:\BC250\m12\mesa05-alias2\vulkan_radeon.dll')){throw 'Missing ICD module witness'}
}finally{$stdout.Dispose();$stderr.Dispose();$p.Dispose()}
"Latest sparse buffer CTS: 21 / 21 PASS. M12.1 in progress; formal certification pending." | Set-Content "$out\progress.txt"
$ui=Start-Process "$Root\ShaderGallery.exe" -ArgumentList $out -WindowStyle Normal -PassThru
@{viewer_pid=$ui.Id;utc=[DateTime]::UtcNow.ToString('o');status='Viewer started; GPU workload finished'} | ConvertTo-Json | Set-Content "$Root\viewer.json"
